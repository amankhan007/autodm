'use client';
import { useEffect, useState } from 'react';
import { useRouter, usePathname } from 'next/navigation';
import Link from 'next/link';
import { motion, AnimatePresence } from 'framer-motion';
import {
  Zap, LayoutDashboard, Megaphone, BarChart2, Settings,
  LogOut, Instagram, CreditCard, FileText, Shield,
  Bell, Menu, X, ChevronRight, AlertCircle
} from 'lucide-react';
import { useAuthStore } from '@/store/authStore';
import toast from 'react-hot-toast';

const navItems = [
  { href: '/dashboard', icon: LayoutDashboard, label: 'Overview' },
  { href: '/dashboard/campaigns', icon: Megaphone, label: 'Campaigns' },
  { href: '/dashboard/analytics', icon: BarChart2, label: 'Analytics' },
  { href: '/dashboard/logs', icon: FileText, label: 'Activity Logs' },
  { href: '/dashboard/instagram', icon: Instagram, label: 'Instagram' },
  { href: '/dashboard/billing', icon: CreditCard, label: 'Billing' },
  { href: '/dashboard/settings', icon: Settings, label: 'Settings' },
];

export default function DashboardLayout({ children }: { children: React.ReactNode }) {
  const router = useRouter();
  const pathname = usePathname();
  const { user, fetchMe, logout, initialized } = useAuthStore();
  const [sidebarOpen, setSidebarOpen] = useState(false);

  useEffect(() => { fetchMe(); }, []);
  useEffect(() => {
    if (initialized && !user) router.push('/auth/login');
  }, [user, initialized]);

  if (!initialized) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <div className="text-center space-y-4">
          <div className="w-12 h-12 rounded-xl btn-glow flex items-center justify-center mx-auto">
            <Zap size={24} className="text-white" />
          </div>
          <div className="spinner mx-auto" />
        </div>
      </div>
    );
  }

  if (!user) return null;

  const isActive = (href: string) => href === '/dashboard' ? pathname === href : pathname.startsWith(href);
  const hasSubscription = user.subscriptionStatus === 'active';

  const Sidebar = () => (
    <aside className="flex flex-col h-full">
      {/* Logo */}
      <div className="px-5 py-5 border-b border-white/5">
        <Link href="/dashboard" className="flex items-center gap-2.5">
          <div className="w-8 h-8 rounded-lg btn-glow flex items-center justify-center flex-shrink-0">
            <Zap size={15} className="text-white" />
          </div>
          <span className="font-extrabold text-lg text-gradient">InstaFlow</span>
        </Link>
      </div>

      {/* Subscription alert */}
      {!hasSubscription && (
        <div className="mx-3 mt-4 p-3 rounded-xl bg-amber-500/10 border border-amber-500/20">
          <div className="flex items-start gap-2">
            <AlertCircle size={14} className="text-amber-400 mt-0.5 flex-shrink-0" />
            <div>
              <p className="text-xs font-semibold text-amber-300">No active plan</p>
              <Link href="/dashboard/billing" className="text-xs text-amber-400/80 hover:text-amber-300 underline">
                Upgrade to Pro →
              </Link>
            </div>
          </div>
        </div>
      )}

      {/* Nav */}
      <nav className="flex-1 px-3 py-4 space-y-1 overflow-y-auto">
        {navItems.map(item => (
          <Link key={item.href} href={item.href}
            onClick={() => setSidebarOpen(false)}
            className={`sidebar-link ${isActive(item.href) ? 'active' : ''}`}>
            <item.icon size={17} />
            <span>{item.label}</span>
            {isActive(item.href) && <ChevronRight size={14} className="ml-auto" />}
          </Link>
        ))}

        {user.role === 'admin' && (
          <Link href="/admin" className="sidebar-link mt-4">
            <Shield size={17} />
            <span>Admin Panel</span>
          </Link>
        )}
      </nav>

      {/* User section */}
      <div className="px-3 py-4 border-t border-white/5 space-y-2">
        {/* Instagram status */}
        <div className="px-3 py-2.5 rounded-xl bg-white/[0.02] border border-white/5 flex items-center gap-3">
          <div className={`w-2 h-2 rounded-full flex-shrink-0 ${user.instagramConnected ? 'bg-green-400' : 'bg-[var(--text-muted)]'}`} />
          <div className="min-w-0 flex-1">
            <p className="text-xs text-[var(--text-muted)]">Instagram</p>
            <p className="text-xs font-medium truncate">
              {user.instagramConnected ? `@${user.instagramUsername}` : 'Not connected'}
            </p>
          </div>
        </div>

        {/* User menu */}
        <div className="flex items-center gap-3 px-3 py-2.5 rounded-xl hover:bg-white/[0.04] transition-colors cursor-pointer group">
          <div className="w-8 h-8 rounded-full btn-glow flex items-center justify-center text-xs font-bold text-white flex-shrink-0">
            {user.name.charAt(0).toUpperCase()}
          </div>
          <div className="min-w-0 flex-1">
            <p className="text-sm font-medium truncate">{user.name}</p>
            <p className="text-xs text-[var(--text-muted)] truncate">{user.email}</p>
          </div>
          <button onClick={logout} className="opacity-0 group-hover:opacity-100 transition-opacity text-[var(--text-muted)] hover:text-red-400">
            <LogOut size={15} />
          </button>
        </div>
      </div>
    </aside>
  );

  return (
    <div className="min-h-screen flex" style={{ position: 'relative', zIndex: 1 }}>
      {/* Desktop sidebar */}
      <div className="hidden lg:flex flex-col w-60 flex-shrink-0 border-r border-white/5"
        style={{ background: 'rgba(10,10,15,0.8)', backdropFilter: 'blur(20px)', position: 'sticky', top: 0, height: '100vh' }}>
        <Sidebar />
      </div>

      {/* Mobile sidebar */}
      <AnimatePresence>
        {sidebarOpen && (
          <>
            <motion.div className="fixed inset-0 bg-black/60 z-40 lg:hidden"
              initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }}
              onClick={() => setSidebarOpen(false)} />
            <motion.div className="fixed left-0 top-0 bottom-0 w-60 z-50 lg:hidden border-r border-white/5 flex flex-col"
              style={{ background: '#0a0a0f' }}
              initial={{ x: -240 }} animate={{ x: 0 }} exit={{ x: -240 }}
              transition={{ type: 'spring', damping: 25, stiffness: 200 }}>
              <Sidebar />
            </motion.div>
          </>
        )}
      </AnimatePresence>

      {/* Main */}
      <div className="flex-1 flex flex-col min-w-0">
        {/* Top bar */}
        <header className="h-14 flex items-center justify-between px-4 lg:px-6 border-b border-white/5 flex-shrink-0"
          style={{ background: 'rgba(10,10,15,0.6)', backdropFilter: 'blur(20px)', position: 'sticky', top: 0, zIndex: 30 }}>
          <button onClick={() => setSidebarOpen(true)} className="lg:hidden text-[var(--text-secondary)] hover:text-white">
            <Menu size={20} />
          </button>

          {/* Breadcrumb */}
          <div className="hidden lg:flex items-center gap-2 text-sm text-[var(--text-muted)]">
            {navItems.find(n => isActive(n.href))?.label || 'Dashboard'}
          </div>

          <div className="flex items-center gap-3 ml-auto">
            <div className={`badge ${hasSubscription ? 'badge-success' : 'badge-warning'} hidden sm:inline-flex`}>
              {hasSubscription ? '✓ Pro Active' : 'Upgrade'}
            </div>
            <button className="relative text-[var(--text-secondary)] hover:text-white p-2 rounded-lg hover:bg-white/5">
              <Bell size={18} />
            </button>
          </div>
        </header>

        {/* Page content */}
        <main className="flex-1 overflow-auto p-4 lg:p-6">
          <motion.div
            key={pathname}
            initial={{ opacity: 0, y: 8 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.3 }}>
            {children}
          </motion.div>
        </main>
      </div>
    </div>
  );
}
