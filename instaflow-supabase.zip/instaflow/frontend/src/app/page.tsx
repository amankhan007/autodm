'use client';
import Link from 'next/link';
import { motion } from 'framer-motion';
import {
  Zap, MessageCircle, TrendingUp, Shield, Clock, Users,
  CheckCircle, ArrowRight, Instagram, Star, ChevronRight
} from 'lucide-react';

const features = [
  { icon: MessageCircle, title: 'Comment → DM Automation', desc: 'Automatically DM users who comment on your posts. Every comment becomes a conversation.' },
  { icon: Zap, title: 'Instant Trigger System', desc: 'Keyword-based triggers ensure only the most relevant comments activate your automation.' },
  { icon: Shield, title: 'Meta Policy Compliant', desc: 'Built on the official Instagram Graph API. 100% safe, no third-party tools.' },
  { icon: Clock, title: 'Smart Delay Engine', desc: 'Randomized delays between 5–20 seconds mimic human behavior and avoid detection.' },
  { icon: TrendingUp, title: 'Real-time Analytics', desc: 'Track comments, DMs sent, success rates, and conversion metrics in a live dashboard.' },
  { icon: Users, title: 'Multi-Campaign Support', desc: 'Run multiple campaigns across different posts simultaneously with individual settings.' },
];

const stats = [
  { value: '50K+', label: 'DMs Sent Daily' },
  { value: '98.7%', label: 'Delivery Rate' },
  { value: '3.2x', label: 'Avg. Conversion Lift' },
  { value: '< 20s', label: 'Response Time' },
];

const pricing = {
  name: 'Pro',
  price: '199',
  period: '/month',
  features: [
    'Unlimited campaigns', 'All Instagram posts',
    'Keyword triggers', 'Smart spam filter',
    'Real-time analytics', 'CSV export',
    'Email notifications', 'Priority support'
  ]
};

export default function LandingPage() {
  return (
    <div className="min-h-screen" style={{ background: 'var(--bg-primary)' }}>

      {/* Nav */}
      <nav className="fixed top-0 inset-x-0 z-50 border-b border-white/5"
        style={{ background: 'rgba(10,10,15,0.8)', backdropFilter: 'blur(20px)' }}>
        <div className="max-w-6xl mx-auto px-6 h-16 flex items-center justify-between">
          <div className="flex items-center gap-2">
            <div className="w-8 h-8 rounded-lg btn-glow flex items-center justify-center">
              <Zap size={16} className="text-white" />
            </div>
            <span className="font-bold text-lg text-gradient">InstaFlow</span>
          </div>
          <div className="hidden md:flex items-center gap-8">
            {['Features', 'Pricing', 'Docs'].map(item => (
              <a key={item} href={`#${item.toLowerCase()}`}
                className="text-sm text-[var(--text-secondary)] hover:text-white transition-colors">
                {item}
              </a>
            ))}
          </div>
          <div className="flex items-center gap-3">
            <Link href="/auth/login"
              className="text-sm font-medium text-[var(--text-secondary)] hover:text-white transition-colors px-4 py-2">
              Sign in
            </Link>
            <Link href="/auth/register"
              className="btn-glow relative text-sm font-semibold text-white px-5 py-2 rounded-lg">
              <span className="relative z-10">Get Started</span>
            </Link>
          </div>
        </div>
      </nav>

      {/* Hero */}
      <section className="pt-32 pb-24 px-6 relative">
        <div className="max-w-4xl mx-auto text-center">
          <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} transition={{ duration: 0.6 }}>
            <div className="inline-flex items-center gap-2 px-4 py-1.5 rounded-full border border-purple-500/30 bg-purple-500/10 text-purple-300 text-sm font-medium mb-8">
              <span className="w-2 h-2 rounded-full bg-green-400 animate-pulse" />
              Now live — Instagram Graph API v19.0
            </div>

            <h1 className="text-5xl md:text-7xl font-extrabold tracking-tight mb-6 leading-none">
              Turn Comments Into
              <br />
              <span className="text-gradient">Conversations</span>
            </h1>
            <p className="text-lg md:text-xl text-[var(--text-secondary)] max-w-2xl mx-auto mb-10 leading-relaxed">
              InstaFlow automatically sends personalized DMs to users who comment on your Instagram posts.
              Policy-compliant, lightning-fast, and built for scale.
            </p>

            <div className="flex flex-col sm:flex-row gap-4 justify-center">
              <Link href="/auth/register"
                className="btn-glow relative inline-flex items-center justify-center gap-2 text-white font-semibold px-8 py-4 rounded-xl text-base">
                <span className="relative z-10 flex items-center gap-2">
                  Start Free Trial <ArrowRight size={18} />
                </span>
              </Link>
              <Link href="#features"
                className="inline-flex items-center justify-center gap-2 text-[var(--text-secondary)] hover:text-white border border-white/10 hover:border-white/20 px-8 py-4 rounded-xl text-base font-medium transition-all">
                See how it works <ChevronRight size={16} />
              </Link>
            </div>
          </motion.div>

          {/* Dashboard preview mockup */}
          <motion.div
            initial={{ opacity: 0, y: 40 }} animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.8, delay: 0.3 }}
            className="mt-20 relative"
          >
            <div className="glass p-1 rounded-2xl shadow-[0_40px_120px_rgba(139,92,246,0.2)]">
              <div className="rounded-xl overflow-hidden bg-[#0f0f18] p-6">
                <div className="flex items-center gap-2 mb-6">
                  <div className="w-3 h-3 rounded-full bg-red-500/60" />
                  <div className="w-3 h-3 rounded-full bg-yellow-500/60" />
                  <div className="w-3 h-3 rounded-full bg-green-500/60" />
                  <div className="ml-4 flex-1 h-6 rounded bg-white/5 max-w-xs" />
                </div>
                <div className="grid grid-cols-4 gap-4 mb-6">
                  {[
                    { label: 'DMs Sent', value: '2,847', color: '#8b5cf6' },
                    { label: 'Comments', value: '3,201', color: '#6366f1' },
                    { label: 'Success Rate', value: '98.4%', color: '#22c55e' },
                    { label: 'Conversion', value: '34.2%', color: '#f59e0b' },
                  ].map(s => (
                    <div key={s.label} className="stat-card">
                      <div className="text-xs text-[var(--text-muted)] mb-1">{s.label}</div>
                      <div className="text-xl font-bold" style={{ color: s.color }}>{s.value}</div>
                    </div>
                  ))}
                </div>
                <div className="h-24 rounded-lg bg-white/[0.02] border border-white/5 flex items-end gap-1 px-4 pb-3 pt-4">
                  {[40,60,45,80,65,90,75,95,70,85,88,92].map((h, i) => (
                    <div key={i} className="flex-1 rounded-sm" style={{
                      height: `${h}%`,
                      background: `linear-gradient(to top, #6366f1, #8b5cf6)`,
                      opacity: 0.7 + (i / 12) * 0.3
                    }} />
                  ))}
                </div>
              </div>
            </div>
            {/* Glow effect */}
            <div className="absolute inset-0 rounded-2xl pointer-events-none"
              style={{ boxShadow: '0 0 80px rgba(139,92,246,0.15)' }} />
          </motion.div>
        </div>
      </section>

      {/* Stats */}
      <section className="py-16 border-y border-white/5">
        <div className="max-w-4xl mx-auto px-6 grid grid-cols-2 md:grid-cols-4 gap-8">
          {stats.map((s, i) => (
            <motion.div key={s.label} className="text-center"
              initial={{ opacity: 0, y: 16 }} whileInView={{ opacity: 1, y: 0 }}
              transition={{ delay: i * 0.1 }} viewport={{ once: true }}>
              <div className="text-3xl font-extrabold text-gradient mb-1">{s.value}</div>
              <div className="text-sm text-[var(--text-muted)]">{s.label}</div>
            </motion.div>
          ))}
        </div>
      </section>

      {/* Features */}
      <section id="features" className="py-24 px-6">
        <div className="max-w-5xl mx-auto">
          <div className="text-center mb-16">
            <h2 className="text-4xl font-extrabold mb-4">Everything you need to grow</h2>
            <p className="text-[var(--text-secondary)] text-lg">Powerful automation tools built for Instagram creators and businesses</p>
          </div>
          <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-5">
            {features.map((f, i) => (
              <motion.div key={f.title} className="glass p-6 hover:border-purple-500/20 transition-all group"
                initial={{ opacity: 0, y: 20 }} whileInView={{ opacity: 1, y: 0 }}
                transition={{ delay: i * 0.08 }} viewport={{ once: true }}>
                <div className="w-10 h-10 rounded-xl bg-purple-500/10 border border-purple-500/20 flex items-center justify-center mb-4 group-hover:bg-purple-500/20 transition-colors">
                  <f.icon size={20} className="text-purple-400" />
                </div>
                <h3 className="font-semibold text-base mb-2">{f.title}</h3>
                <p className="text-sm text-[var(--text-secondary)] leading-relaxed">{f.desc}</p>
              </motion.div>
            ))}
          </div>
        </div>
      </section>

      {/* Pricing */}
      <section id="pricing" className="py-24 px-6">
        <div className="max-w-md mx-auto text-center">
          <h2 className="text-4xl font-extrabold mb-4">Simple pricing</h2>
          <p className="text-[var(--text-secondary)] mb-12">Everything included. No hidden fees.</p>

          <motion.div
            className="glass-strong p-8 rounded-2xl text-left relative overflow-hidden"
            initial={{ opacity: 0, scale: 0.95 }} whileInView={{ opacity: 1, scale: 1 }}
            viewport={{ once: true }}>
            <div className="absolute top-0 right-0 w-48 h-48 rounded-full pointer-events-none"
              style={{ background: 'radial-gradient(circle, rgba(139,92,246,0.15), transparent 70%)', transform: 'translate(30%,-30%)' }} />

            <div className="badge badge-brand mb-4">Most Popular</div>
            <h3 className="text-2xl font-bold mb-1">InstaFlow Pro</h3>
            <div className="flex items-end gap-1 mb-6">
              <span className="text-5xl font-extrabold text-gradient">₹{pricing.price}</span>
              <span className="text-[var(--text-secondary)] mb-1">{pricing.period}</span>
            </div>

            <ul className="space-y-3 mb-8">
              {pricing.features.map(f => (
                <li key={f} className="flex items-center gap-3 text-sm">
                  <CheckCircle size={16} className="text-green-400 flex-shrink-0" />
                  <span>{f}</span>
                </li>
              ))}
            </ul>

            <Link href="/auth/register"
              className="btn-glow relative w-full flex items-center justify-center gap-2 text-white font-semibold py-3.5 rounded-xl">
              <span className="relative z-10 flex items-center gap-2">
                <Instagram size={18} /> Connect Instagram & Start
              </span>
            </Link>
            <p className="text-xs text-center text-[var(--text-muted)] mt-3">Auto-renews monthly. Cancel anytime.</p>
          </motion.div>
        </div>
      </section>

      {/* Footer */}
      <footer className="border-t border-white/5 py-10 px-6">
        <div className="max-w-6xl mx-auto flex flex-col md:flex-row items-center justify-between gap-4">
          <div className="flex items-center gap-2">
            <div className="w-6 h-6 rounded btn-glow flex items-center justify-center">
              <Zap size={12} className="text-white" />
            </div>
            <span className="font-bold text-gradient">InstaFlow</span>
          </div>
          <p className="text-xs text-[var(--text-muted)]">
            © {new Date().getFullYear()} InstaFlow. Built with ❤️ using Meta Instagram Graph API.
          </p>
          <div className="flex gap-6 text-xs text-[var(--text-muted)]">
            <a href="#" className="hover:text-white transition-colors">Privacy</a>
            <a href="#" className="hover:text-white transition-colors">Terms</a>
            <a href="#" className="hover:text-white transition-colors">Support</a>
          </div>
        </div>
      </footer>
    </div>
  );
}
