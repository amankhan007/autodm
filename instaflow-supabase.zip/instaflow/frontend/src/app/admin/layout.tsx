'use client';
import { useEffect } from 'react';
import { useRouter } from 'next/navigation';
import { useAuthStore } from '@/store/authStore';

export default function AdminLayout({ children }: { children: React.ReactNode }) {
  const { user, fetchMe, initialized } = useAuthStore();
  const router = useRouter();

  useEffect(() => { fetchMe(); }, []);
  useEffect(() => {
    if (initialized && (!user || user.role !== 'admin')) router.push('/dashboard');
  }, [user, initialized]);

  if (!initialized || !user) return null;

  return (
    <div className="min-h-screen p-6" style={{ position: 'relative', zIndex: 1 }}>
      {children}
    </div>
  );
}
