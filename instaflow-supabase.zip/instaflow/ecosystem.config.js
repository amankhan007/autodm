module.exports = {
  apps: [
    {
      name: 'instaflow-api',
      script: './backend/server.js',
      cwd: '/var/www/instaflow',
      instances: 2,
      exec_mode: 'cluster',
      watch: false,
      max_memory_restart: '500M',
      env: {
        NODE_ENV: 'production',
        PORT: 5000
      },
      error_file: './logs/api-error.log',
      out_file: './logs/api-out.log',
      log_file: './logs/api-combined.log',
      time: true,
      merge_logs: true,
    },
    {
      name: 'instaflow-worker',
      script: './backend/queues/dmQueue.js',
      cwd: '/var/www/instaflow',
      instances: 1,
      watch: false,
      max_memory_restart: '300M',
      env: {
        NODE_ENV: 'production'
      },
      error_file: './logs/worker-error.log',
      out_file: './logs/worker-out.log',
      time: true,
    },
    {
      name: 'instaflow-frontend',
      script: 'npm',
      args: 'start',
      cwd: '/var/www/instaflow/frontend',
      instances: 1,
      watch: false,
      env: {
        NODE_ENV: 'production',
        PORT: 3000
      },
      error_file: './logs/frontend-error.log',
      out_file: './logs/frontend-out.log',
      time: true,
    }
  ]
};
