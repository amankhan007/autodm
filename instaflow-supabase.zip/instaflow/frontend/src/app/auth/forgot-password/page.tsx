'use client';
import { useState } from 'react';
import Link from 'next/link';
import { useRouter } from 'next/navigation';
import { motion, AnimatePresence } from 'framer-motion';
import { Zap, Mail, ArrowRight, Loader2, KeyRound, Lock, RefreshCw } from 'lucide-react';
import toast from 'react-hot-toast';
import api from '@/lib/api';

type Step = 'email' | 'otp' | 'reset';

export default function ForgotPasswordPage() {
  const router = useRouter();
  const [step, setStep] = useState<Step>('email');
  const [email, setEmail] = useState('');
  const [otp, setOtp] = useState('');
  const [resetToken, setResetToken] = useState('');
  const [password, setPassword] = useState('');
  const [loading, setLoading] = useState(false);

  const sendOTP = async (e: React.FormEvent) => {
    e.preventDefault();
    setLoading(true);
    try {
      await api.post('/api/auth/forgot-password', { email });
      toast.success('OTP sent to your email!');
      setStep('otp');
    } catch (err: any) {
      toast.error(err?.response?.data?.message || 'Failed to send OTP');
    } finally { setLoading(false); }
  };

  const verifyOTP = async (e: React.FormEvent) => {
    e.preventDefault();
    setLoading(true);
    try {
      const { data } = await api.post('/api/auth/verify-otp', { email, otp });
      setResetToken(data.resetToken);
      setStep('reset');
    } catch (err: any) {
      toast.error(err?.response?.data?.message || 'Invalid OTP');
    } finally { setLoading(false); }
  };

  const resetPassword = async (e: React.FormEvent) => {
    e.preventDefault();
    if (password.length < 8) return toast.error('Password must be at least 8 characters');
    setLoading(true);
    try {
      await api.post('/api/auth/reset-password', { resetToken, password });
      toast.success('Password reset successfully!');
      router.push('/auth/login');
    } catch (err: any) {
      toast.error(err?.response?.data?.message || 'Reset failed');
    } finally { setLoading(false); }
  };

  const stepConfig = [
    { label: 'Email', icon: Mail },
    { label: 'Verify', icon: KeyRound },
    { label: 'Reset', icon: Lock },
  ];
  const stepIndex = { email: 0, otp: 1, reset: 2 }[step];

  return (
    <div className="min-h-screen flex items-center justify-center px-4">
      <motion.div className="w-full max-w-md"
        initial={{ opacity: 0, y: 24 }} animate={{ opacity: 1, y: 0 }}>

        <div className="text-center mb-10">
          <Link href="/" className="inline-flex items-center gap-2 mb-6">
            <div className="w-10 h-10 rounded-xl btn-glow flex items-center justify-center">
              <Zap size={20} className="text-white" />
            </div>
            <span className="text-2xl font-extrabold text-gradient">InstaFlow</span>
          </Link>
          <h1 className="text-2xl font-bold">Reset your password</h1>
          <p className="text-[var(--text-secondary)] text-sm mt-1">We'll send an OTP to your email</p>
        </div>

        {/* Step indicator */}
        <div className="flex items-center justify-center gap-2 mb-8">
          {stepConfig.map((s, i) => (
            <div key={s.label} className="flex items-center gap-2">
              <div className={`w-8 h-8 rounded-full flex items-center justify-center text-xs font-bold transition-all ${
                i <= stepIndex ? 'bg-purple-500 text-white' : 'bg-white/5 text-[var(--text-muted)]'
              }`}>
                {i < stepIndex ? '✓' : i + 1}
              </div>
              <span className={`text-xs ${i <= stepIndex ? 'text-purple-300' : 'text-[var(--text-muted)]'}`}>{s.label}</span>
              {i < 2 && <div className={`w-8 h-px ${i < stepIndex ? 'bg-purple-500' : 'bg-white/10'}`} />}
            </div>
          ))}
        </div>

        <div className="glass-strong rounded-2xl p-8">
          <AnimatePresence mode="wait">
            {step === 'email' && (
              <motion.form key="email" onSubmit={sendOTP} className="space-y-5"
                initial={{ opacity: 0, x: 20 }} animate={{ opacity: 1, x: 0 }} exit={{ opacity: 0, x: -20 }}>
                <div>
                  <label className="text-xs font-semibold text-[var(--text-secondary)] uppercase tracking-wider mb-2 block">Email address</label>
                  <div className="relative">
                    <Mail size={16} className="absolute left-3.5 top-1/2 -translate-y-1/2 text-[var(--text-muted)]" />
                    <input type="email" required value={email} onChange={e => setEmail(e.target.value)}
                      placeholder="you@example.com" className="input-dark pl-10" />
                  </div>
                </div>
                <button type="submit" disabled={loading}
                  className="btn-glow relative w-full flex items-center justify-center gap-2 text-white font-semibold py-3 rounded-xl disabled:opacity-60">
                  <span className="relative z-10 flex items-center gap-2">
                    {loading ? <Loader2 size={18} className="animate-spin" /> : <ArrowRight size={18} />}
                    {loading ? 'Sending OTP…' : 'Send OTP'}
                  </span>
                </button>
              </motion.form>
            )}

            {step === 'otp' && (
              <motion.form key="otp" onSubmit={verifyOTP} className="space-y-5"
                initial={{ opacity: 0, x: 20 }} animate={{ opacity: 1, x: 0 }} exit={{ opacity: 0, x: -20 }}>
                <div>
                  <label className="text-xs font-semibold text-[var(--text-secondary)] uppercase tracking-wider mb-2 block">6-digit OTP</label>
                  <input type="text" required maxLength={6} value={otp} onChange={e => setOtp(e.target.value.replace(/\D/g, ''))}
                    placeholder="123456"
                    className="input-dark text-center text-2xl tracking-[1rem] font-mono" />
                  <p className="text-xs text-[var(--text-muted)] mt-2 text-center">OTP sent to {email}</p>
                </div>
                <button type="submit" disabled={loading || otp.length < 6}
                  className="btn-glow relative w-full flex items-center justify-center gap-2 text-white font-semibold py-3 rounded-xl disabled:opacity-60">
                  <span className="relative z-10 flex items-center gap-2">
                    {loading ? <Loader2 size={18} className="animate-spin" /> : <KeyRound size={18} />}
                    {loading ? 'Verifying…' : 'Verify OTP'}
                  </span>
                </button>
                <button type="button" onClick={() => setStep('email')}
                  className="w-full flex items-center justify-center gap-2 text-sm text-[var(--text-secondary)] hover:text-white py-2">
                  <RefreshCw size={14} /> Resend OTP
                </button>
              </motion.form>
            )}

            {step === 'reset' && (
              <motion.form key="reset" onSubmit={resetPassword} className="space-y-5"
                initial={{ opacity: 0, x: 20 }} animate={{ opacity: 1, x: 0 }} exit={{ opacity: 0, x: -20 }}>
                <div>
                  <label className="text-xs font-semibold text-[var(--text-secondary)] uppercase tracking-wider mb-2 block">New Password</label>
                  <div className="relative">
                    <Lock size={16} className="absolute left-3.5 top-1/2 -translate-y-1/2 text-[var(--text-muted)]" />
                    <input type="password" required value={password} onChange={e => setPassword(e.target.value)}
                      placeholder="Min 8 characters" className="input-dark pl-10" />
                  </div>
                </div>
                <button type="submit" disabled={loading}
                  className="btn-glow relative w-full flex items-center justify-center gap-2 text-white font-semibold py-3 rounded-xl disabled:opacity-60">
                  <span className="relative z-10 flex items-center gap-2">
                    {loading ? <Loader2 size={18} className="animate-spin" /> : <Lock size={18} />}
                    {loading ? 'Resetting…' : 'Reset Password'}
                  </span>
                </button>
              </motion.form>
            )}
          </AnimatePresence>

          <div className="mt-6 text-center text-sm text-[var(--text-secondary)]">
            <Link href="/auth/login" className="text-purple-400 hover:text-purple-300">← Back to login</Link>
          </div>
        </div>
      </motion.div>
    </div>
  );
}
