import type { Metadata } from 'next';
import { Toaster } from 'react-hot-toast';
import './globals.css';

export const metadata: Metadata = {
  title: 'InstaFlow — Instagram Automation Platform',
  description: 'Automate Instagram DMs with Comment-to-DM workflows. Built for creators and businesses.',
  keywords: 'instagram automation, comment to dm, instagram dms, social media automation',
  openGraph: {
    title: 'InstaFlow',
    description: 'Instagram Comment-to-DM Automation',
    type: 'website',
  },
};

export default function RootLayout({ children }: { children: React.ReactNode }) {
  return (
    <html lang="en" className="dark">
      <body>
        <div className="mesh-bg" />
        {children}
        <Toaster
          position="top-right"
          toastOptions={{
            style: {
              background: 'rgba(15,15,24,0.95)',
              color: '#f1f0f5',
              border: '1px solid rgba(255,255,255,0.1)',
              backdropFilter: 'blur(20px)',
              borderRadius: '10px',
              fontSize: '14px',
            },
            success: { iconTheme: { primary: '#22c55e', secondary: 'transparent' } },
            error: { iconTheme: { primary: '#ef4444', secondary: 'transparent' } },
          }}
        />
      </body>
    </html>
  );
}
