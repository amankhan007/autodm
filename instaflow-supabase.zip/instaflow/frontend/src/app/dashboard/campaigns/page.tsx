'use client';
import { useEffect, useState } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import {
  Plus, Megaphone, Play, Pause, Trash2, Edit3,
  ChevronRight, CheckSquare, Square, Image, MessageSquare,
  Loader2, Zap, X, Tag, Clock, Shield
} from 'lucide-react';
import toast from 'react-hot-toast';
import api from '@/lib/api';

interface Post { id: string; media_url?: string; thumbnail_url?: string; caption?: string; media_type: string; timestamp: string; like_count?: number; comments_count?: number; }
interface Campaign { _id: string; name: string; status: string; messageTemplate: string; selectedPosts: any[]; stats: any; keywordTriggers: string[]; useKeywordTrigger: boolean; createdAt: string; }

const TEMPLATE_VARS = ['{{username}}', '{{comment}}'];

function CampaignModal({ campaign, onClose, onSave }: { campaign?: Campaign; onClose: () => void; onSave: () => void }) {
  const [step, setStep] = useState(1);
  const [posts, setPosts] = useState<Post[]>([]);
  const [selectedPosts, setSelectedPosts] = useState<Post[]>(campaign?.selectedPosts || []);
  const [form, setForm] = useState({
    name: campaign?.name || '',
    messageTemplate: campaign?.messageTemplate || 'Hey {{username}}! Thanks for your comment 🙌\n\nHere\'s what you asked about: ',
    keywordTriggers: campaign?.keywordTriggers?.join(', ') || '',
    useKeywordTrigger: campaign?.useKeywordTrigger || false,
    delayMin: 5, delayMax: 20,
    spamFilter: true,
  });
  const [loadingPosts, setLoadingPosts] = useState(false);
  const [saving, setSaving] = useState(false);

  useEffect(() => {
    setLoadingPosts(true);
    api.get('/api/instagram/posts?limit=24')
      .then(r => setPosts(r.data.posts || []))
      .catch(() => toast.error('Failed to load posts'))
      .finally(() => setLoadingPosts(false));
  }, []);

  const togglePost = (post: Post) => {
    setSelectedPosts(prev =>
      prev.find(p => p.id === post.id)
        ? prev.filter(p => p.id !== post.id)
        : [...prev, post]
    );
  };

  const handleSave = async () => {
    if (!form.name.trim()) return toast.error('Campaign name is required');
    if (!selectedPosts.length) return toast.error('Select at least one post');
    if (!form.messageTemplate.trim()) return toast.error('Message template is required');

    setSaving(true);
    try {
      const payload = {
        name: form.name,
        messageTemplate: form.messageTemplate,
        selectedPosts: selectedPosts.map(p => ({
          postId: p.id, mediaUrl: p.media_url, thumbnailUrl: p.thumbnail_url,
          caption: p.caption, mediaType: p.media_type,
        })),
        keywordTriggers: form.useKeywordTrigger ? form.keywordTriggers.split(',').map(k => k.trim()).filter(Boolean) : [],
        useKeywordTrigger: form.useKeywordTrigger,
        delayMin: form.delayMin, delayMax: form.delayMax,
        spamFilter: form.spamFilter,
      };

      if (campaign) await api.put(`/api/campaigns/${campaign._id}`, payload);
      else await api.post('/api/campaigns', payload);

      toast.success(campaign ? 'Campaign updated!' : 'Campaign created!');
      onSave();
    } catch (err: any) {
      toast.error(err?.response?.data?.message || 'Failed to save campaign');
    } finally { setSaving(false); }
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4">
      <motion.div className="absolute inset-0 bg-black/70" onClick={onClose}
        initial={{ opacity: 0 }} animate={{ opacity: 1 }} />
      <motion.div className="relative w-full max-w-2xl glass-strong rounded-2xl overflow-hidden"
        initial={{ opacity: 0, scale: 0.95, y: 20 }} animate={{ opacity: 1, scale: 1, y: 0 }}>

        {/* Header */}
        <div className="flex items-center justify-between p-5 border-b border-white/8">
          <h2 className="font-bold text-lg">{campaign ? 'Edit Campaign' : 'New Campaign'}</h2>
          <button onClick={onClose} className="text-[var(--text-muted)] hover:text-white"><X size={20} /></button>
        </div>

        {/* Steps */}
        <div className="flex border-b border-white/5">
          {['Setup', 'Select Posts', 'Message'].map((s, i) => (
            <button key={s} onClick={() => setStep(i + 1)}
              className={`flex-1 py-3 text-sm font-medium transition-colors ${step === i + 1 ? 'text-purple-300 border-b-2 border-purple-500' : 'text-[var(--text-muted)] hover:text-white'}`}>
              {i + 1}. {s}
            </button>
          ))}
        </div>

        <div className="p-5 max-h-[60vh] overflow-y-auto">
          {/* Step 1: Setup */}
          {step === 1 && (
            <div className="space-y-4">
              <div>
                <label className="text-xs font-semibold text-[var(--text-secondary)] uppercase tracking-wider mb-2 block">Campaign Name *</label>
                <input value={form.name} onChange={e => setForm(p => ({ ...p, name: e.target.value }))}
                  placeholder="e.g. Product Launch DMs" className="input-dark" />
              </div>

              <div className="grid grid-cols-2 gap-4">
                <div>
                  <label className="text-xs font-semibold text-[var(--text-secondary)] uppercase tracking-wider mb-2 block flex items-center gap-1">
                    <Clock size={11} /> Min Delay (sec)
                  </label>
                  <input type="number" min={0} max={60} value={form.delayMin}
                    onChange={e => setForm(p => ({ ...p, delayMin: +e.target.value }))}
                    className="input-dark" />
                </div>
                <div>
                  <label className="text-xs font-semibold text-[var(--text-secondary)] uppercase tracking-wider mb-2 block flex items-center gap-1">
                    <Clock size={11} /> Max Delay (sec)
                  </label>
                  <input type="number" min={0} max={300} value={form.delayMax}
                    onChange={e => setForm(p => ({ ...p, delayMax: +e.target.value }))}
                    className="input-dark" />
                </div>
              </div>

              <div className="flex items-center justify-between p-4 rounded-xl bg-white/[0.03] border border-white/8">
                <div className="flex items-center gap-3">
                  <Shield size={16} className="text-green-400" />
                  <div>
                    <p className="text-sm font-medium">Spam Filter</p>
                    <p className="text-xs text-[var(--text-muted)]">Skip obvious spam comments</p>
                  </div>
                </div>
                <label className="toggle">
                  <input type="checkbox" checked={form.spamFilter} onChange={e => setForm(p => ({ ...p, spamFilter: e.target.checked }))} />
                  <span className="toggle-slider" />
                </label>
              </div>

              <div className="p-4 rounded-xl bg-white/[0.03] border border-white/8 space-y-3">
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-3">
                    <Tag size={16} className="text-purple-400" />
                    <div>
                      <p className="text-sm font-medium">Keyword Triggers</p>
                      <p className="text-xs text-[var(--text-muted)]">Only reply to matching comments</p>
                    </div>
                  </div>
                  <label className="toggle">
                    <input type="checkbox" checked={form.useKeywordTrigger}
                      onChange={e => setForm(p => ({ ...p, useKeywordTrigger: e.target.checked }))} />
                    <span className="toggle-slider" />
                  </label>
                </div>
                {form.useKeywordTrigger && (
                  <input value={form.keywordTriggers}
                    onChange={e => setForm(p => ({ ...p, keywordTriggers: e.target.value }))}
                    placeholder="price, link, details, info (comma-separated)" className="input-dark text-sm" />
                )}
              </div>
            </div>
          )}

          {/* Step 2: Posts */}
          {step === 2 && (
            <div>
              <div className="flex items-center justify-between mb-4">
                <p className="text-sm text-[var(--text-secondary)]">
                  {selectedPosts.length} post{selectedPosts.length !== 1 ? 's' : ''} selected
                </p>
                {selectedPosts.length > 0 && (
                  <button onClick={() => setSelectedPosts([])} className="text-xs text-red-400 hover:text-red-300">Clear all</button>
                )}
              </div>
              {loadingPosts ? (
                <div className="flex items-center justify-center h-48">
                  <div className="spinner" />
                </div>
              ) : posts.length === 0 ? (
                <div className="text-center py-12 text-[var(--text-muted)]">
                  <Image size={32} className="mx-auto mb-3 opacity-40" />
                  <p className="text-sm">No posts found. Connect Instagram first.</p>
                </div>
              ) : (
                <div className="post-grid">
                  {posts.map(post => {
                    const selected = selectedPosts.some(p => p.id === post.id);
                    const imgSrc = post.thumbnail_url || post.media_url;
                    return (
                      <div key={post.id} className={`post-thumb ${selected ? 'selected' : ''}`}
                        onClick={() => togglePost(post)}>
                        {imgSrc ? (
                          <img src={imgSrc} alt="" className="w-full h-full object-cover" />
                        ) : (
                          <div className="w-full h-full flex items-center justify-center bg-white/5">
                            <Image size={20} className="text-[var(--text-muted)]" />
                          </div>
                        )}
                        <div className="post-thumb-overlay">
                          {selected ? <CheckSquare size={24} className="text-white" /> : <Square size={24} className="text-white" />}
                        </div>
                        {selected && (
                          <div className="absolute top-1.5 right-1.5 w-5 h-5 rounded-full bg-purple-500 flex items-center justify-center">
                            <CheckSquare size={10} className="text-white" />
                          </div>
                        )}
                      </div>
                    );
                  })}
                </div>
              )}
            </div>
          )}

          {/* Step 3: Message */}
          {step === 3 && (
            <div className="space-y-4">
              <div>
                <div className="flex items-center justify-between mb-2">
                  <label className="text-xs font-semibold text-[var(--text-secondary)] uppercase tracking-wider">
                    DM Template *
                  </label>
                  <div className="flex gap-2">
                    {TEMPLATE_VARS.map(v => (
                      <button key={v} type="button"
                        onClick={() => setForm(p => ({ ...p, messageTemplate: p.messageTemplate + v }))}
                        className="text-xs px-2.5 py-1 rounded-lg bg-purple-500/10 border border-purple-500/20 text-purple-300 hover:bg-purple-500/20 font-mono">
                        {v}
                      </button>
                    ))}
                  </div>
                </div>
                <textarea value={form.messageTemplate}
                  onChange={e => setForm(p => ({ ...p, messageTemplate: e.target.value }))}
                  rows={6} className="input-dark resize-none font-mono text-sm"
                  placeholder="Hi {{username}}! Thanks for commenting..." />
                <p className="text-xs text-[var(--text-muted)] mt-1">{form.messageTemplate.length}/1000 characters</p>
              </div>

              <div className="p-4 rounded-xl bg-purple-500/5 border border-purple-500/20">
                <p className="text-xs font-semibold text-purple-300 mb-2 flex items-center gap-1">
                  <MessageSquare size={12} /> Preview
                </p>
                <p className="text-sm text-[var(--text-secondary)] whitespace-pre-wrap">
                  {form.messageTemplate
                    .replace(/\{\{username\}\}/g, 'john_doe')
                    .replace(/\{\{comment\}\}/g, 'What\'s the price?')}
                </p>
              </div>
            </div>
          )}
        </div>

        {/* Footer */}
        <div className="flex items-center justify-between p-5 border-t border-white/8">
          <button onClick={() => step > 1 ? setStep(s => s - 1) : onClose()}
            className="px-4 py-2 text-sm text-[var(--text-secondary)] hover:text-white border border-white/10 rounded-xl">
            {step > 1 ? '← Back' : 'Cancel'}
          </button>
          {step < 3 ? (
            <button onClick={() => setStep(s => s + 1)}
              className="btn-glow relative px-6 py-2 text-sm font-semibold text-white rounded-xl">
              <span className="relative z-10">Next →</span>
            </button>
          ) : (
            <button onClick={handleSave} disabled={saving}
              className="btn-glow relative px-6 py-2 text-sm font-semibold text-white rounded-xl disabled:opacity-60">
              <span className="relative z-10 flex items-center gap-2">
                {saving && <Loader2 size={14} className="animate-spin" />}
                {campaign ? 'Update' : 'Create Campaign'}
              </span>
            </button>
          )}
        </div>
      </motion.div>
    </div>
  );
}

export default function CampaignsPage() {
  const [campaigns, setCampaigns] = useState<Campaign[]>([]);
  const [loading, setLoading] = useState(true);
  const [showModal, setShowModal] = useState(false);
  const [editCampaign, setEditCampaign] = useState<Campaign | undefined>();
  const [toggling, setToggling] = useState<string | null>(null);

  const fetchCampaigns = async () => {
    try {
      const { data } = await api.get('/api/campaigns');
      setCampaigns(data.campaigns);
    } catch { toast.error('Failed to load campaigns'); }
    finally { setLoading(false); }
  };

  useEffect(() => { fetchCampaigns(); }, []);

  const toggleStatus = async (campaign: Campaign) => {
    const newStatus = campaign.status === 'active' ? 'inactive' : 'active';
    setToggling(campaign._id);
    try {
      await api.patch(`/api/campaigns/${campaign._id}/status`, { status: newStatus });
      setCampaigns(prev => prev.map(c => c._id === campaign._id ? { ...c, status: newStatus } : c));
      toast.success(`Campaign ${newStatus === 'active' ? 'activated' : 'paused'}`);
    } catch (err: any) {
      toast.error(err?.response?.data?.message || 'Failed to update');
    } finally { setToggling(null); }
  };

  const deleteCampaign = async (id: string) => {
    if (!confirm('Delete this campaign? This cannot be undone.')) return;
    try {
      await api.delete(`/api/campaigns/${id}`);
      setCampaigns(prev => prev.filter(c => c._id !== id));
      toast.success('Campaign deleted');
    } catch { toast.error('Failed to delete'); }
  };

  const statusColor = (s: string) => ({ active: '#22c55e', inactive: '#ef4444', paused: '#f59e0b', draft: '#8b8a9e' }[s] || '#8b8a9e');

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-2xl font-bold">Campaigns</h1>
          <p className="text-sm text-[var(--text-secondary)] mt-0.5">Manage your Comment-to-DM automations</p>
        </div>
        <button onClick={() => { setEditCampaign(undefined); setShowModal(true); }}
          className="btn-glow relative flex items-center gap-2 text-white font-semibold px-4 py-2.5 rounded-xl text-sm">
          <span className="relative z-10 flex items-center gap-2"><Plus size={16} /> New Campaign</span>
        </button>
      </div>

      {loading ? (
        <div className="space-y-3">{[...Array(3)].map((_, i) => <div key={i} className="skeleton h-24 rounded-2xl" />)}</div>
      ) : campaigns.length === 0 ? (
        <div className="glass rounded-2xl p-16 text-center">
          <Megaphone size={40} className="mx-auto mb-4 opacity-20" />
          <h3 className="font-semibold mb-2">No campaigns yet</h3>
          <p className="text-sm text-[var(--text-secondary)] mb-6">Create your first Comment-to-DM campaign</p>
          <button onClick={() => setShowModal(true)}
            className="btn-glow relative inline-flex items-center gap-2 text-white font-semibold px-5 py-2.5 rounded-xl text-sm">
            <span className="relative z-10 flex items-center gap-2"><Plus size={16} /> Create Campaign</span>
          </button>
        </div>
      ) : (
        <div className="space-y-3">
          {campaigns.map((c, i) => (
            <motion.div key={c._id} className="glass p-5 hover:border-purple-500/20 transition-all"
              initial={{ opacity: 0, y: 12 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: i * 0.06 }}>
              <div className="flex items-start justify-between gap-4">
                <div className="flex items-start gap-4 flex-1 min-w-0">
                  <div className="w-10 h-10 rounded-xl flex items-center justify-center flex-shrink-0"
                    style={{ background: statusColor(c.status) + '18' }}>
                    <Zap size={18} style={{ color: statusColor(c.status) }} />
                  </div>
                  <div className="min-w-0 flex-1">
                    <div className="flex items-center gap-2 flex-wrap">
                      <h3 className="font-semibold truncate">{c.name}</h3>
                      <span className="badge" style={{
                        background: statusColor(c.status) + '18',
                        color: statusColor(c.status),
                        border: `1px solid ${statusColor(c.status)}30`
                      }}>
                        {c.status}
                      </span>
                    </div>
                    <p className="text-xs text-[var(--text-muted)] mt-1">
                      {c.selectedPosts.length} post{c.selectedPosts.length !== 1 ? 's' : ''} •{' '}
                      {c.keywordTriggers?.length ? `Keywords: ${c.keywordTriggers.slice(0,2).join(', ')}${c.keywordTriggers.length > 2 ? '…' : ''}` : 'All comments'}
                    </p>
                    <div className="flex items-center gap-4 mt-2 text-xs text-[var(--text-muted)]">
                      <span className="text-green-400">{c.stats?.dmsSent || 0} sent</span>
                      <span className="text-red-400">{c.stats?.dmsFailed || 0} failed</span>
                      <span>{c.stats?.totalComments || 0} comments</span>
                    </div>
                  </div>
                </div>
                <div className="flex items-center gap-2 flex-shrink-0">
                  <button onClick={() => toggleStatus(c)} disabled={toggling === c._id}
                    className={`flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-xs font-semibold transition-all ${
                      c.status === 'active'
                        ? 'bg-red-500/10 text-red-400 hover:bg-red-500/20 border border-red-500/20'
                        : 'bg-green-500/10 text-green-400 hover:bg-green-500/20 border border-green-500/20'
                    }`}>
                    {toggling === c._id ? <Loader2 size={12} className="animate-spin" /> : c.status === 'active' ? <Pause size={12} /> : <Play size={12} />}
                    {c.status === 'active' ? 'Pause' : 'Activate'}
                  </button>
                  <button onClick={() => { setEditCampaign(c); setShowModal(true); }}
                    className="p-1.5 rounded-lg text-[var(--text-muted)] hover:text-white hover:bg-white/5">
                    <Edit3 size={15} />
                  </button>
                  <button onClick={() => deleteCampaign(c._id)}
                    className="p-1.5 rounded-lg text-[var(--text-muted)] hover:text-red-400 hover:bg-red-500/10">
                    <Trash2 size={15} />
                  </button>
                </div>
              </div>
            </motion.div>
          ))}
        </div>
      )}

      <AnimatePresence>
        {showModal && (
          <CampaignModal
            campaign={editCampaign}
            onClose={() => { setShowModal(false); setEditCampaign(undefined); }}
            onSave={() => { setShowModal(false); fetchCampaigns(); }}
          />
        )}
      </AnimatePresence>
    </div>
  );
}
