'use client';
import { useEffect, useState, useCallback } from 'react';
import { motion } from 'framer-motion';
import { FileText, Download, Filter, CheckCircle, XCircle, SkipForward, Activity, Search, RefreshCw } from 'lucide-react';
import toast from 'react-hot-toast';
import api from '@/lib/api';

interface Log { _id: string; commenterUsername?: string; commentText?: string; dmStatus: string; skipReason?: string; errorMessage?: string; postId?: string; createdAt: string; dmSentAt?: string; campaignId?: { name: string }; }

const STATUS_OPTIONS = ['all', 'success', 'failed', 'skipped', 'queued', 'pending'];

export default function LogsPage() {
  const [logs, setLogs] = useState<Log[]>([]);
  const [total, setTotal] = useState(0);
  const [page, setPage] = useState(1);
  const [loading, setLoading] = useState(true);
  const [exporting, setExporting] = useState(false);
  const [filters, setFilters] = useState({ status: 'all', search: '' });

  const fetchLogs = useCallback(async () => {
    setLoading(true);
    try {
      const params = new URLSearchParams({ page: String(page), limit: '50' });
      if (filters.status !== 'all') params.set('status', filters.status);
      const { data } = await api.get(`/api/logs?${params}`);
      setLogs(data.logs || []);
      setTotal(data.total || 0);
    } catch { toast.error('Failed to load logs'); }
    finally { setLoading(false); }
  }, [page, filters.status]);

  useEffect(() => { fetchLogs(); }, [fetchLogs]);

  const handleExport = async () => {
    setExporting(true);
    try {
      const params = new URLSearchParams();
      if (filters.status !== 'all') params.set('status', filters.status);
      const response = await api.get(`/api/logs/export?${params}`, { responseType: 'blob' });
      const url = URL.createObjectURL(new Blob([response.data]));
      const a = document.createElement('a');
      a.href = url;
      a.download = `instaflow-logs-${Date.now()}.csv`;
      a.click();
      URL.revokeObjectURL(url);
      toast.success('Logs exported!');
    } catch { toast.error('Export failed'); }
    finally { setExporting(false); }
  };

  const filteredLogs = filters.search
    ? logs.filter(l => l.commenterUsername?.toLowerCase().includes(filters.search.toLowerCase()) || l.commentText?.toLowerCase().includes(filters.search.toLowerCase()))
    : logs;

  const statusIcon = (s: string) => ({ success: <CheckCircle size={13} />, failed: <XCircle size={13} />, skipped: <SkipForward size={13} />, queued: <Activity size={13} /> }[s] || <Activity size={13} />);
  const statusColor = (s: string) => ({ success: '#22c55e', failed: '#ef4444', skipped: '#f59e0b', queued: '#6366f1', pending: '#8b8a9e' }[s] || '#8b8a9e');

  return (
    <div className="space-y-5">
      <div className="flex items-start justify-between gap-4 flex-wrap">
        <div>
          <h1 className="text-2xl font-bold">Activity Logs</h1>
          <p className="text-sm text-[var(--text-secondary)] mt-0.5">{total.toLocaleString()} total events</p>
        </div>
        <div className="flex items-center gap-2">
          <button onClick={fetchLogs} className="p-2 rounded-xl border border-white/10 text-[var(--text-secondary)] hover:text-white hover:bg-white/5 transition-all">
            <RefreshCw size={16} className={loading ? 'animate-spin' : ''} />
          </button>
          <button onClick={handleExport} disabled={exporting}
            className="flex items-center gap-2 px-4 py-2 rounded-xl border border-white/10 text-sm text-[var(--text-secondary)] hover:text-white hover:bg-white/5 transition-all disabled:opacity-60">
            <Download size={15} /> {exporting ? 'Exporting…' : 'Export CSV'}
          </button>
        </div>
      </div>

      {/* Filters */}
      <div className="glass rounded-xl p-4 flex items-center gap-3 flex-wrap">
        <div className="relative flex-1 min-w-48">
          <Search size={14} className="absolute left-3 top-1/2 -translate-y-1/2 text-[var(--text-muted)]" />
          <input value={filters.search} onChange={e => setFilters(p => ({ ...p, search: e.target.value }))}
            placeholder="Search by username or comment…" className="input-dark pl-9 text-sm py-2" />
        </div>
        <div className="flex items-center gap-1">
          {STATUS_OPTIONS.map(s => (
            <button key={s} onClick={() => { setFilters(p => ({ ...p, status: s })); setPage(1); }}
              className={`px-3 py-1.5 rounded-lg text-xs font-medium transition-all capitalize ${
                filters.status === s
                  ? 'bg-purple-500/20 text-purple-300 border border-purple-500/30'
                  : 'text-[var(--text-muted)] hover:text-white hover:bg-white/5'
              }`}>
              {s}
            </button>
          ))}
        </div>
      </div>

      {/* Logs table */}
      <div className="glass rounded-2xl overflow-hidden">
        {loading ? (
          <div className="p-6 space-y-3">{[...Array(8)].map((_, i) => <div key={i} className="skeleton h-12 rounded-xl" />)}</div>
        ) : filteredLogs.length === 0 ? (
          <div className="text-center py-16 text-[var(--text-muted)]">
            <FileText size={32} className="mx-auto mb-3 opacity-20" />
            <p className="text-sm">No logs found</p>
          </div>
        ) : (
          <>
            {/* Header */}
            <div className="grid grid-cols-12 gap-3 px-5 py-3 border-b border-white/5 text-xs font-semibold text-[var(--text-muted)] uppercase tracking-wider">
              <div className="col-span-2">Status</div>
              <div className="col-span-2">User</div>
              <div className="col-span-4">Comment</div>
              <div className="col-span-2">Campaign</div>
              <div className="col-span-2">Time</div>
            </div>

            <div className="divide-y divide-white/[0.04]">
              {filteredLogs.map((log, i) => (
                <motion.div key={log._id}
                  className="grid grid-cols-12 gap-3 px-5 py-3.5 hover:bg-white/[0.02] transition-colors text-sm"
                  initial={{ opacity: 0 }} animate={{ opacity: 1 }} transition={{ delay: i * 0.02 }}>

                  <div className="col-span-2 flex items-center gap-1.5" style={{ color: statusColor(log.dmStatus) }}>
                    {statusIcon(log.dmStatus)}
                    <span className="capitalize text-xs font-medium">{log.dmStatus}</span>
                    {log.skipReason && (
                      <span className="text-xs text-[var(--text-muted)]">({log.skipReason})</span>
                    )}
                  </div>

                  <div className="col-span-2 text-[var(--text-secondary)] truncate">
                    @{log.commenterUsername || '—'}
                  </div>

                  <div className="col-span-4 text-[var(--text-secondary)] truncate">
                    {log.commentText || <span className="text-[var(--text-muted)] italic">No text</span>}
                    {log.errorMessage && (
                      <p className="text-xs text-red-400 truncate mt-0.5">{log.errorMessage}</p>
                    )}
                  </div>

                  <div className="col-span-2 text-[var(--text-muted)] text-xs truncate">
                    {(log.campaignId as any)?.name || '—'}
                  </div>

                  <div className="col-span-2 text-[var(--text-muted)] text-xs">
                    {new Date(log.createdAt).toLocaleString('en-IN', { dateStyle: 'short', timeStyle: 'short' })}
                  </div>
                </motion.div>
              ))}
            </div>

            {/* Pagination */}
            <div className="flex items-center justify-between px-5 py-3 border-t border-white/5">
              <p className="text-xs text-[var(--text-muted)]">Showing {filteredLogs.length} of {total}</p>
              <div className="flex gap-2">
                <button onClick={() => setPage(p => Math.max(1, p - 1))} disabled={page === 1}
                  className="px-3 py-1.5 text-xs rounded-lg border border-white/10 text-[var(--text-secondary)] disabled:opacity-40 hover:bg-white/5">
                  ← Prev
                </button>
                <span className="px-3 py-1.5 text-xs text-[var(--text-secondary)]">Page {page}</span>
                <button onClick={() => setPage(p => p + 1)} disabled={filteredLogs.length < 50}
                  className="px-3 py-1.5 text-xs rounded-lg border border-white/10 text-[var(--text-secondary)] disabled:opacity-40 hover:bg-white/5">
                  Next →
                </button>
              </div>
            </div>
          </>
        )}
      </div>
    </div>
  );
}
