'use client';
import { useState } from 'react';
import { motion } from 'framer-motion';
import { User, Bell, Lock, Loader2, CheckCircle } from 'lucide-react';
import toast from 'react-hot-toast';
import api from '@/lib/api';
import { useAuthStore } from '@/store/authStore';

export default function SettingsPage() {
  const { user, updateUser } = useAuthStore();
  const [profileForm, setProfileForm] = useState({ name: user?.name || '', emailNotifications: user?.emailNotifications ?? true });
  const [passForm, setPassForm] = useState({ currentPassword: '', newPassword: '', confirmPassword: '' });
  const [savingProfile, setSavingProfile] = useState(false);
  const [savingPass, setSavingPass] = useState(false);

  const saveProfile = async (e: React.FormEvent) => {
    e.preventDefault();
    setSavingProfile(true);
    try {
      const { data } = await api.put('/api/auth/update-profile', profileForm);
      updateUser(data.user);
      toast.success('Profile updated!');
    } catch (err: any) {
      toast.error(err?.response?.data?.message || 'Failed to update profile');
    } finally { setSavingProfile(false); }
  };

  const changePassword = async (e: React.FormEvent) => {
    e.preventDefault();
    if (passForm.newPassword !== passForm.confirmPassword) return toast.error('Passwords do not match');
    if (passForm.newPassword.length < 8) return toast.error('Password must be at least 8 characters');
    setSavingPass(true);
    try {
      await api.put('/api/auth/change-password', { currentPassword: passForm.currentPassword, newPassword: passForm.newPassword });
      toast.success('Password changed!');
      setPassForm({ currentPassword: '', newPassword: '', confirmPassword: '' });
    } catch (err: any) {
      toast.error(err?.response?.data?.message || 'Failed to change password');
    } finally { setSavingPass(false); }
  };

  return (
    <div className="space-y-6 max-w-xl">
      <div>
        <h1 className="text-2xl font-bold">Settings</h1>
        <p className="text-sm text-[var(--text-secondary)] mt-0.5">Manage your account preferences</p>
      </div>

      {/* Profile */}
      <motion.div className="glass rounded-2xl p-6" initial={{ opacity: 0, y: 16 }} animate={{ opacity: 1, y: 0 }}>
        <h3 className="font-semibold mb-5 flex items-center gap-2"><User size={16} className="text-purple-400" /> Profile</h3>
        <form onSubmit={saveProfile} className="space-y-4">
          <div>
            <label className="text-xs font-semibold text-[var(--text-secondary)] uppercase tracking-wider mb-2 block">Full Name</label>
            <input value={profileForm.name} onChange={e => setProfileForm(p => ({ ...p, name: e.target.value }))}
              className="input-dark" placeholder="Your name" />
          </div>
          <div>
            <label className="text-xs font-semibold text-[var(--text-secondary)] uppercase tracking-wider mb-2 block">Email</label>
            <input value={user?.email || ''} disabled className="input-dark opacity-50 cursor-not-allowed" />
          </div>
          <div className="flex items-center justify-between p-4 rounded-xl bg-white/[0.03] border border-white/8">
            <div className="flex items-center gap-3">
              <Bell size={15} className="text-purple-400" />
              <div>
                <p className="text-sm font-medium">Email Notifications</p>
                <p className="text-xs text-[var(--text-muted)]">Daily reports and alerts</p>
              </div>
            </div>
            <label className="toggle">
              <input type="checkbox" checked={profileForm.emailNotifications}
                onChange={e => setProfileForm(p => ({ ...p, emailNotifications: e.target.checked }))} />
              <span className="toggle-slider" />
            </label>
          </div>
          <button type="submit" disabled={savingProfile}
            className="btn-glow relative flex items-center gap-2 text-white font-semibold px-5 py-2.5 rounded-xl text-sm disabled:opacity-60">
            <span className="relative z-10 flex items-center gap-2">
              {savingProfile ? <Loader2 size={14} className="animate-spin" /> : <CheckCircle size={14} />}
              Save Changes
            </span>
          </button>
        </form>
      </motion.div>

      {/* Password */}
      <motion.div className="glass rounded-2xl p-6" initial={{ opacity: 0, y: 16 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: 0.1 }}>
        <h3 className="font-semibold mb-5 flex items-center gap-2"><Lock size={16} className="text-purple-400" /> Change Password</h3>
        <form onSubmit={changePassword} className="space-y-4">
          {[
            { label: 'Current Password', key: 'currentPassword', placeholder: '••••••••' },
            { label: 'New Password', key: 'newPassword', placeholder: 'Min 8 characters' },
            { label: 'Confirm New Password', key: 'confirmPassword', placeholder: 'Repeat new password' },
          ].map(f => (
            <div key={f.key}>
              <label className="text-xs font-semibold text-[var(--text-secondary)] uppercase tracking-wider mb-2 block">{f.label}</label>
              <input type="password" required
                value={passForm[f.key as keyof typeof passForm]}
                onChange={e => setPassForm(p => ({ ...p, [f.key]: e.target.value }))}
                placeholder={f.placeholder} className="input-dark" />
            </div>
          ))}
          <button type="submit" disabled={savingPass}
            className="btn-glow relative flex items-center gap-2 text-white font-semibold px-5 py-2.5 rounded-xl text-sm disabled:opacity-60">
            <span className="relative z-10 flex items-center gap-2">
              {savingPass ? <Loader2 size={14} className="animate-spin" /> : <Lock size={14} />}
              Update Password
            </span>
          </button>
        </form>
      </motion.div>

      {/* Danger zone */}
      <motion.div className="rounded-2xl p-6 border border-red-500/20 bg-red-500/[0.03]"
        initial={{ opacity: 0, y: 16 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: 0.2 }}>
        <h3 className="font-semibold mb-2 text-red-400">Danger Zone</h3>
        <p className="text-sm text-[var(--text-secondary)] mb-4">These actions are irreversible. Please proceed with caution.</p>
        <button className="px-4 py-2 text-sm font-medium text-red-400 border border-red-500/30 rounded-xl hover:bg-red-500/10 transition-all"
          onClick={() => toast.error('Contact support to delete your account.')}>
          Delete Account
        </button>
      </motion.div>
    </div>
  );
}
