'use client';
import { useEffect, useState } from 'react';
import { useSearchParams } from 'next/navigation';
import { motion } from 'framer-motion';
import { Instagram, CheckCircle, Link as LinkIcon, Unlink, Image, Users, Heart, Loader2, RefreshCw, ExternalLink } from 'lucide-react';
import toast from 'react-hot-toast';
import api from '@/lib/api';
import { useAuthStore } from '@/store/authStore';

interface IGAccount {
  id: string; username: string; name: string; biography?: string;
  followers_count: number; follows_count: number; media_count: number;
  profile_picture_url?: string; website?: string;
}

export default function InstagramPage() {
  const { user, fetchMe } = useAuthStore();
  const searchParams = useSearchParams();
  const [account, setAccount] = useState<IGAccount | null>(null);
  const [posts, setPosts] = useState<any[]>([]);
  const [authUrl, setAuthUrl] = useState('');
  const [loading, setLoading] = useState(true);
  const [disconnecting, setDisconnecting] = useState(false);

  useEffect(() => {
    // Handle OAuth callback messages
    const success = searchParams.get('success');
    const error = searchParams.get('error');
    if (success === 'instagram_connected') toast.success('Instagram connected successfully! 🎉');
    if (error === 'instagram_auth_failed') toast.error('Instagram connection failed. Please try again.');
    if (error === 'no_instagram_business') toast.error('No Instagram Business account found. Ensure your account is a Business/Creator account.');

    fetchData();
  }, []);

  const fetchData = async () => {
    setLoading(true);
    try {
      const [accountRes, authUrlRes] = await Promise.all([
        api.get('/api/instagram/account').catch(() => ({ data: { connected: false } })),
        api.get('/api/instagram/auth-url').catch(() => ({ data: { url: '' } })),
      ]);

      setAuthUrl(authUrlRes.data.url);

      if (accountRes.data.connected && accountRes.data.account) {
        setAccount(accountRes.data.account);
        const postsRes = await api.get('/api/instagram/posts?limit=9');
        setPosts(postsRes.data.posts || []);
      }
    } catch {}
    finally { setLoading(false); }
  };

  const handleDisconnect = async () => {
    if (!confirm('Disconnect your Instagram account? All active campaigns will be paused.')) return;
    setDisconnecting(true);
    try {
      await api.delete('/api/instagram/disconnect');
      toast.success('Instagram disconnected');
      setAccount(null);
      setPosts([]);
      await fetchMe();
    } catch { toast.error('Failed to disconnect'); }
    finally { setDisconnecting(false); }
  };

  const handleRefreshToken = async () => {
    try {
      await api.post('/api/instagram/refresh-token');
      toast.success('Access token refreshed');
    } catch { toast.error('Failed to refresh token'); }
  };

  if (loading) {
    return (
      <div className="space-y-4">
        <div className="skeleton h-8 w-48 rounded-xl" />
        <div className="skeleton h-48 rounded-2xl" />
      </div>
    );
  }

  return (
    <div className="space-y-6 max-w-2xl">
      <div>
        <h1 className="text-2xl font-bold">Instagram</h1>
        <p className="text-sm text-[var(--text-secondary)] mt-0.5">Connect your Instagram Business account</p>
      </div>

      {!account ? (
        <motion.div className="glass rounded-2xl p-10 text-center"
          initial={{ opacity: 0, y: 16 }} animate={{ opacity: 1, y: 0 }}>
          <div className="w-16 h-16 rounded-2xl mx-auto mb-6 flex items-center justify-center"
            style={{ background: 'linear-gradient(135deg, #f09433, #e6683c, #dc2743, #cc2366, #bc1888)' }}>
            <Instagram size={32} className="text-white" />
          </div>
          <h2 className="text-xl font-bold mb-2">Connect Instagram</h2>
          <p className="text-[var(--text-secondary)] text-sm mb-2 max-w-sm mx-auto">
            Connect your Instagram Business or Creator account to start automating DMs.
          </p>
          <div className="flex flex-col items-center gap-2 mb-8 text-xs text-[var(--text-muted)]">
            <p>✓ Requires Instagram Business or Creator account</p>
            <p>✓ Linked to a Facebook Page</p>
            <p>✓ Uses official Meta Graph API — 100% safe</p>
          </div>
          <a href={authUrl}
            className="btn-glow relative inline-flex items-center gap-2 text-white font-semibold px-8 py-3.5 rounded-xl">
            <span className="relative z-10 flex items-center gap-2">
              <Instagram size={18} /> Connect with Instagram
            </span>
          </a>
          <p className="text-xs text-[var(--text-muted)] mt-4">
            You'll be redirected to Meta's official OAuth page
          </p>
        </motion.div>
      ) : (
        <>
          {/* Account card */}
          <motion.div className="glass rounded-2xl p-6" initial={{ opacity: 0, y: 16 }} animate={{ opacity: 1, y: 0 }}>
            <div className="flex items-start gap-4">
              {account.profile_picture_url ? (
                <img src={account.profile_picture_url} alt=""
                  className="w-16 h-16 rounded-full object-cover ring-2 ring-purple-500/30" />
              ) : (
                <div className="w-16 h-16 rounded-full flex items-center justify-center bg-purple-500/20">
                  <Instagram size={28} className="text-purple-400" />
                </div>
              )}
              <div className="flex-1 min-w-0">
                <div className="flex items-center gap-2 flex-wrap">
                  <h2 className="text-lg font-bold">@{account.username}</h2>
                  <span className="badge badge-success">Connected</span>
                </div>
                {account.name && <p className="text-sm text-[var(--text-secondary)] mt-0.5">{account.name}</p>}
                {account.biography && (
                  <p className="text-xs text-[var(--text-muted)] mt-1 line-clamp-2">{account.biography}</p>
                )}
                <div className="flex items-center gap-5 mt-3">
                  {[
                    { icon: Users, value: account.followers_count?.toLocaleString(), label: 'Followers' },
                    { icon: Heart, value: account.follows_count?.toLocaleString(), label: 'Following' },
                    { icon: Image, value: account.media_count?.toLocaleString(), label: 'Posts' },
                  ].map(s => (
                    <div key={s.label} className="text-center">
                      <p className="text-sm font-bold">{s.value || '—'}</p>
                      <p className="text-xs text-[var(--text-muted)]">{s.label}</p>
                    </div>
                  ))}
                </div>
              </div>
            </div>

            <div className="flex items-center gap-3 mt-5 pt-5 border-t border-white/5">
              <button onClick={handleRefreshToken}
                className="flex items-center gap-2 px-4 py-2 rounded-xl border border-white/10 text-sm text-[var(--text-secondary)] hover:text-white hover:bg-white/5 transition-all">
                <RefreshCw size={14} /> Refresh Token
              </button>
              {account.website && (
                <a href={account.website} target="_blank" rel="noopener noreferrer"
                  className="flex items-center gap-2 px-4 py-2 rounded-xl border border-white/10 text-sm text-[var(--text-secondary)] hover:text-white hover:bg-white/5 transition-all">
                  <ExternalLink size={14} /> Website
                </a>
              )}
              <button onClick={handleDisconnect} disabled={disconnecting}
                className="ml-auto flex items-center gap-2 px-4 py-2 rounded-xl border border-red-500/20 text-sm text-red-400 hover:bg-red-500/10 transition-all disabled:opacity-60">
                {disconnecting ? <Loader2 size={14} className="animate-spin" /> : <Unlink size={14} />}
                Disconnect
              </button>
            </div>
          </motion.div>

          {/* Recent posts preview */}
          {posts.length > 0 && (
            <motion.div className="glass rounded-2xl p-5" initial={{ opacity: 0, y: 16 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: 0.1 }}>
              <h3 className="font-semibold mb-4 flex items-center gap-2">
                <Image size={16} className="text-purple-400" /> Recent Posts
              </h3>
              <div className="post-grid">
                {posts.map(post => (
                  <div key={post.id} className="post-thumb">
                    {post.thumbnail_url || post.media_url ? (
                      <img src={post.thumbnail_url || post.media_url} alt="" className="w-full h-full object-cover" />
                    ) : (
                      <div className="w-full h-full flex items-center justify-center bg-white/5">
                        <Image size={20} className="text-[var(--text-muted)]" />
                      </div>
                    )}
                    <div className="post-thumb-overlay">
                      <div className="text-center text-white">
                        <p className="text-xs font-bold">{post.like_count || 0} ❤️</p>
                        <p className="text-xs">{post.comments_count || 0} 💬</p>
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            </motion.div>
          )}
        </>
      )}
    </div>
  );
}
