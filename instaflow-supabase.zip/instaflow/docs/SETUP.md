# InstaFlow — Setup Guide (Supabase Edition)

## Table of Contents
1. [Prerequisites](#1-prerequisites)
2. [Supabase Setup](#2-supabase-setup)
3. [Local Development](#3-local-development)
4. [Meta App Setup](#4-meta-app-setup)
5. [Razorpay Setup](#5-razorpay-setup)
6. [VPS Deployment](#6-vps-deployment)
7. [API Reference](#7-api-reference)

---

## 1. Prerequisites

| Tool | Version |
|---|---|
| Node.js | 18+ |
| Redis | 6+ |
| Supabase account | free tier works |
| Meta Developer account | — |
| Razorpay account | — |
| VPS (Ubuntu 22.04) | optional — for production |

---

## 2. Supabase Setup

### Step 1 — Create project
1. Go to https://supabase.com → New project
2. Choose a region close to your users (e.g. `ap-south-1` for India)
3. Set a strong database password and save it

### Step 2 — Run the schema
1. In the Supabase dashboard → **SQL Editor**
2. Click **New query**
3. Paste the entire contents of `backend/config/supabase-schema.sql`
4. Click **Run** — all tables, indexes, triggers and RLS are created

### Step 3 — Get your API keys
Go to **Project Settings → API**:

| Variable | Where to find |
|---|---|
| `SUPABASE_URL` | Project URL (e.g. `https://xxxx.supabase.co`) |
| `SUPABASE_SERVICE_ROLE_KEY` | `service_role` key (secret — never expose to frontend) |

> ⚠️ **Use the `service_role` key on the backend only.** It bypasses Row Level Security and has full DB access. Never put it in the frontend.

### Step 4 — Verify tables
After running the schema you should see these tables in **Table Editor**:
- `users`
- `campaigns`
- `logs`
- `payments`

---

## 3. Local Development

```bash
# 1. Clone and install
git clone https://github.com/your-repo/instaflow.git
cd instaflow
npm run install:all

# 2. Backend config
cp backend/.env.example backend/.env
# Open backend/.env and fill in:
#   SUPABASE_URL, SUPABASE_SERVICE_ROLE_KEY
#   JWT_SECRET, ENCRYPTION_KEY
#   REDIS_*, META_*, RAZORPAY_*, SMTP_*

# 3. Frontend config
cp frontend/.env.example frontend/.env.local
# Set NEXT_PUBLIC_API_URL and NEXT_PUBLIC_RAZORPAY_KEY

# 4. Start Redis (if local)
redis-server

# 5. Run dev servers
npm run dev           # starts both Next.js (3000) + Express (5000)

# 6. Start DM worker (separate terminal)
cd backend && node queues/dmQueue.js
```

### Generate ENCRYPTION_KEY
```bash
node -e "console.log(require('crypto').randomBytes(32).toString('hex'))"
```
Paste the output as your `ENCRYPTION_KEY` in `.env`.

---

## 4. Meta App Setup

### Create Meta App
1. Go to https://developers.facebook.com → My Apps → Create App
2. Type: **Business**
3. Add product: **Instagram Graph API**
4. Add product: **Webhooks**

### Permissions to request
```
instagram_basic
instagram_manage_comments
instagram_manage_messages
pages_show_list
pages_read_engagement
business_management
```

### Webhook config
| Field | Value |
|---|---|
| Callback URL | `https://yourdomain.com/api/webhook` |
| Verify Token | Same as `META_WEBHOOK_VERIFY_TOKEN` in `.env` |
| Subscriptions | `comments`, `messages` |

### Env vars to set
```
META_APP_ID=...
META_APP_SECRET=...
META_WEBHOOK_VERIFY_TOKEN=...  # any string you choose
INSTAGRAM_REDIRECT_URI=https://yourdomain.com/api/instagram/callback
```

---

## 5. Razorpay Setup

### Create subscription plan
1. Dashboard → Products → Subscriptions → Plans → Create
2. **Name**: InstaFlow Pro
3. **Amount**: `19900` (paise = ₹199)
4. **Interval**: Monthly
5. Copy the **Plan ID** → `RAZORPAY_PLAN_ID`

### Webhook
1. Settings → Webhooks → Add webhook
2. **URL**: `https://yourdomain.com/api/webhook/razorpay`
3. Events: `subscription.charged`, `subscription.cancelled`, `payment.failed`
4. Copy **Webhook Secret** → `RAZORPAY_WEBHOOK_SECRET`

---

## 6. VPS Deployment

```bash
# ── Server setup ──────────────────────────────────────────────
sudo apt update && sudo apt upgrade -y
sudo apt install -y curl git nginx certbot python3-certbot-nginx ufw

# Node.js 20
curl -fsSL https://deb.nodesource.com/setup_20.x | sudo -E bash -
sudo apt install -y nodejs

# Redis
sudo apt install -y redis-server
sudo systemctl enable --now redis-server
# Set password: sudo nano /etc/redis/redis.conf → requirepass your_pass

# PM2
sudo npm i -g pm2

# Firewall
sudo ufw allow ssh && sudo ufw allow 'Nginx Full' && sudo ufw enable

# ── Deploy app ────────────────────────────────────────────────
sudo mkdir -p /var/www/instaflow && sudo chown $USER:$USER /var/www/instaflow
cd /var/www/instaflow
git clone https://github.com/your-repo/instaflow.git .
npm run install:all

# Env files
cp backend/.env.example backend/.env
nano backend/.env   # fill all values including Supabase keys

cp frontend/.env.example frontend/.env.local
nano frontend/.env.local

# Build Next.js
cd frontend && npm run build && cd ..

# Create log dirs
mkdir -p logs backend/logs

# Nginx
sudo cp docs/nginx.conf /etc/nginx/sites-available/instaflow
# Edit: replace yourdomain.com
sudo ln -sf /etc/nginx/sites-available/instaflow /etc/nginx/sites-enabled/
sudo nginx -t && sudo systemctl reload nginx

# SSL
sudo certbot --nginx -d yourdomain.com -d www.yourdomain.com

# PM2
pm2 start ecosystem.config.js
pm2 save && pm2 startup

# Verify
pm2 status
curl https://yourdomain.com/health
# → {"status":"healthy","db":"supabase",...}
```

### Cron jobs (optional)
```bash
# Weekly token refresh + daily reports
(crontab -l 2>/dev/null; echo "0 0 * * 0 node /var/www/instaflow/backend/utils/tokenRefresher.js >> /var/log/instaflow-cron.log 2>&1") | crontab -
(crontab -l 2>/dev/null; echo "0 8 * * * node /var/www/instaflow/backend/utils/dailyReport.js >> /var/log/instaflow-cron.log 2>&1") | crontab -
```

---

## 7. API Reference

All protected routes require `Authorization: Bearer <token>`.

### Auth
| Method | Endpoint | Body | Description |
|---|---|---|---|
| POST | `/api/auth/register` | `{name, email, password}` | Register |
| POST | `/api/auth/login` | `{email, password}` | Login |
| POST | `/api/auth/logout` | — | Clear cookie |
| GET  | `/api/auth/me` | — | Current user |
| POST | `/api/auth/forgot-password` | `{email}` | Send OTP |
| POST | `/api/auth/verify-otp` | `{email, otp}` | Verify OTP |
| POST | `/api/auth/reset-password` | `{resetToken, password}` | Reset |
| PUT  | `/api/auth/update-profile` | `{name, emailNotifications}` | Update profile |
| PUT  | `/api/auth/change-password` | `{currentPassword, newPassword}` | Change pass |

### Instagram
| Method | Endpoint | Description |
|---|---|---|
| GET | `/api/instagram/auth-url` | Get OAuth URL |
| GET | `/api/instagram/callback` | OAuth callback (Meta redirects here) |
| GET | `/api/instagram/account` | Get connected IG account |
| GET | `/api/instagram/posts` | List IG posts |
| POST | `/api/instagram/refresh-token` | Refresh long-lived token |
| DELETE | `/api/instagram/disconnect` | Unlink Instagram |

### Campaigns
| Method | Endpoint | Description |
|---|---|---|
| GET | `/api/campaigns` | List all |
| POST | `/api/campaigns` | Create |
| GET | `/api/campaigns/:id` | Get one |
| PUT | `/api/campaigns/:id` | Update |
| PATCH | `/api/campaigns/:id/status` | `{status: "active"\|"inactive"\|"paused"}` |
| DELETE | `/api/campaigns/:id` | Delete |
| GET | `/api/campaigns/:id/logs` | Campaign-specific logs |

### Webhook
| Method | Endpoint | Description |
|---|---|---|
| GET | `/api/webhook` | Meta verification challenge |
| POST | `/api/webhook` | Receive comment/message events |
| POST | `/api/webhook/razorpay` | Razorpay payment events |

### Dashboard
| Method | Endpoint | Description |
|---|---|---|
| GET | `/api/dashboard/stats` | Stats + 7-day chart data |
| GET | `/api/dashboard/activity` | Last 20 log entries |

### Payments
| Method | Endpoint | Description |
|---|---|---|
| POST | `/api/payments/create-subscription` | Create Razorpay subscription |
| POST | `/api/payments/verify` | Verify payment signature |
| GET | `/api/payments/history` | Payment history |
| POST | `/api/payments/cancel` | Cancel subscription |

### Logs
| Method | Endpoint | Description |
|---|---|---|
| GET | `/api/logs?page=1&status=success` | Paginated logs |
| GET | `/api/logs/export` | CSV download |

### Admin (role=admin only)
| Method | Endpoint | Description |
|---|---|---|
| GET | `/api/admin/stats` | Platform-wide stats |
| GET | `/api/admin/users` | All users with pagination |
| PATCH | `/api/admin/users/:id/toggle` | Suspend/activate |
| PATCH | `/api/admin/users/:id/subscription` | `{status, daysToAdd}` |

---

## Supabase vs MongoDB — what changed

| Concern | Before (MongoDB) | After (Supabase) |
|---|---|---|
| Connection | `mongoose.connect(MONGODB_URI)` | `createClient(SUPABASE_URL, SERVICE_KEY)` |
| Models | Mongoose schemas | Plain JS objects with Supabase client queries |
| Queries | `Model.find({...})` | `supabase.from('table').select('*').eq(...)` |
| Migrations | Auto schema sync | `supabase-schema.sql` run in SQL Editor |
| Realtime | Polling | Can upgrade to Supabase Realtime subscriptions |
| Backups | Atlas auto-backup | Supabase daily backups (paid plans) |
| Dashboard | MongoDB Atlas UI | Supabase Table Editor / SQL Editor |

## Troubleshooting

**"relation users does not exist"**
→ You haven't run `supabase-schema.sql` yet. Go to SQL Editor and run it.

**"Invalid API key"**
→ You're using the `anon` key instead of `service_role`. Use service_role in backend `.env`.

**DMs not sending**
→ Check worker: `pm2 logs instaflow-worker`
→ Verify token not expired: hit `POST /api/instagram/refresh-token`

**Webhook not verifying**
→ `META_WEBHOOK_VERIFY_TOKEN` in `.env` must exactly match what you set in Meta App dashboard
