'use client';
import { useEffect, useState } from 'react';
import { motion } from 'framer-motion';
import {
  AreaChart, Area, BarChart, Bar, PieChart, Pie, Cell,
  XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, Legend
} from 'recharts';
import { TrendingUp, Send, MessageCircle, XCircle, SkipForward, RefreshCw } from 'lucide-react';
import api from '@/lib/api';

const CustomTooltip = ({ active, payload, label }: any) => {
  if (!active || !payload?.length) return null;
  return (
    <div style={{ background: 'rgba(10,10,20,0.95)', border: '1px solid rgba(255,255,255,0.1)', borderRadius: 10, padding: '10px 14px', fontSize: 12 }}>
      <p className="font-semibold text-white mb-2">{label}</p>
      {payload.map((p: any) => (
        <p key={p.name} style={{ color: p.color }} className="text-xs">{p.name}: <strong>{p.value}</strong></p>
      ))}
    </div>
  );
};

const COLORS = ['#8b5cf6', '#ef4444', '#f59e0b', '#6366f1'];

export default function AnalyticsPage() {
  const [chartData, setChartData] = useState<any[]>([]);
  const [stats, setStats] = useState<any>(null);
  const [loading, setLoading] = useState(true);
  const [range, setRange] = useState(7);

  const fetchData = async () => {
    setLoading(true);
    try {
      const { data } = await api.get('/api/dashboard/stats');
      setStats(data.stats);
      setChartData(data.chartData || []);
    } catch {}
    finally { setLoading(false); }
  };

  useEffect(() => { fetchData(); }, [range]);

  const pieData = stats ? [
    { name: 'Sent', value: stats.totalDmsSent },
    { name: 'Failed', value: stats.totalDmsFailed },
    { name: 'Skipped', value: stats.totalSkipped },
  ] : [];

  const summaryCards = stats ? [
    { label: 'Total Comments Received', value: stats.totalComments, icon: MessageCircle, color: '#6366f1' },
    { label: 'DMs Successfully Sent', value: stats.totalDmsSent, icon: Send, color: '#8b5cf6' },
    { label: 'DMs Failed', value: stats.totalDmsFailed, icon: XCircle, color: '#ef4444' },
    { label: 'Conversion Rate', value: `${stats.conversionRate}%`, icon: TrendingUp, color: '#22c55e' },
  ] : [];

  if (loading) return (
    <div className="space-y-5">
      <div className="skeleton h-8 w-48 rounded-xl" />
      <div className="grid grid-cols-2 lg:grid-cols-4 gap-4">
        {[...Array(4)].map((_, i) => <div key={i} className="skeleton h-24 rounded-2xl" />)}
      </div>
      <div className="grid lg:grid-cols-3 gap-4">
        <div className="skeleton h-72 rounded-2xl lg:col-span-2" />
        <div className="skeleton h-72 rounded-2xl" />
      </div>
    </div>
  );

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-2xl font-bold">Analytics</h1>
          <p className="text-sm text-[var(--text-secondary)] mt-0.5">Campaign performance insights</p>
        </div>
        <div className="flex items-center gap-2">
          <div className="flex bg-white/[0.04] border border-white/8 rounded-xl p-1 gap-1">
            {[7, 14, 30].map(d => (
              <button key={d} onClick={() => setRange(d)}
                className={`px-3 py-1.5 rounded-lg text-xs font-medium transition-all ${range === d ? 'bg-purple-500/20 text-purple-300' : 'text-[var(--text-muted)] hover:text-white'}`}>
                {d}d
              </button>
            ))}
          </div>
          <button onClick={fetchData} className="p-2 rounded-xl border border-white/10 text-[var(--text-secondary)] hover:text-white hover:bg-white/5 transition-all">
            <RefreshCw size={16} />
          </button>
        </div>
      </div>

      {/* Summary cards */}
      <div className="grid grid-cols-2 lg:grid-cols-4 gap-4">
        {summaryCards.map((s, i) => (
          <motion.div key={s.label} className="stat-card"
            initial={{ opacity: 0, y: 16 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: i * 0.07 }}>
            <div className="w-9 h-9 rounded-xl flex items-center justify-center mb-3"
              style={{ background: s.color + '18', border: `1px solid ${s.color}30` }}>
              <s.icon size={16} style={{ color: s.color }} />
            </div>
            <div className="text-2xl font-extrabold mb-0.5" style={{ color: s.color }}>{s.value}</div>
            <div className="text-xs text-[var(--text-muted)] leading-tight">{s.label}</div>
          </motion.div>
        ))}
      </div>

      {/* Area chart + Pie chart */}
      <div className="grid lg:grid-cols-3 gap-4">
        <motion.div className="glass p-5 lg:col-span-2"
          initial={{ opacity: 0, y: 16 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: 0.3 }}>
          <h3 className="font-semibold mb-4 text-sm flex items-center gap-2">
            <TrendingUp size={15} className="text-purple-400" /> Comments vs DMs Sent
          </h3>
          <ResponsiveContainer width="100%" height={220}>
            <AreaChart data={chartData}>
              <defs>
                <linearGradient id="gComments" x1="0" y1="0" x2="0" y2="1">
                  <stop offset="5%" stopColor="#6366f1" stopOpacity={0.3} />
                  <stop offset="95%" stopColor="#6366f1" stopOpacity={0} />
                </linearGradient>
                <linearGradient id="gSent" x1="0" y1="0" x2="0" y2="1">
                  <stop offset="5%" stopColor="#8b5cf6" stopOpacity={0.3} />
                  <stop offset="95%" stopColor="#8b5cf6" stopOpacity={0} />
                </linearGradient>
              </defs>
              <CartesianGrid strokeDasharray="3 3" stroke="rgba(255,255,255,0.04)" />
              <XAxis dataKey="label" tick={{ fill: '#8b8a9e', fontSize: 11 }} axisLine={false} tickLine={false} />
              <YAxis tick={{ fill: '#8b8a9e', fontSize: 11 }} axisLine={false} tickLine={false} />
              <Tooltip content={<CustomTooltip />} />
              <Legend wrapperStyle={{ fontSize: 12, color: '#8b8a9e', paddingTop: 12 }} />
              <Area type="monotone" dataKey="comments" name="Comments" stroke="#6366f1" fill="url(#gComments)" strokeWidth={2} dot={false} />
              <Area type="monotone" dataKey="sent" name="DMs Sent" stroke="#8b5cf6" fill="url(#gSent)" strokeWidth={2} dot={false} />
            </AreaChart>
          </ResponsiveContainer>
        </motion.div>

        <motion.div className="glass p-5"
          initial={{ opacity: 0, y: 16 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: 0.35 }}>
          <h3 className="font-semibold mb-4 text-sm">DM Outcome Breakdown</h3>
          {pieData.every(d => d.value === 0) ? (
            <div className="flex items-center justify-center h-48 text-[var(--text-muted)] text-sm">No data yet</div>
          ) : (
            <>
              <ResponsiveContainer width="100%" height={180}>
                <PieChart>
                  <Pie data={pieData} cx="50%" cy="50%" innerRadius={50} outerRadius={75}
                    paddingAngle={3} dataKey="value">
                    {pieData.map((_, i) => <Cell key={i} fill={COLORS[i]} strokeWidth={0} />)}
                  </Pie>
                  <Tooltip content={<CustomTooltip />} />
                </PieChart>
              </ResponsiveContainer>
              <div className="space-y-2 mt-2">
                {pieData.map((d, i) => (
                  <div key={d.name} className="flex items-center justify-between text-xs">
                    <div className="flex items-center gap-2">
                      <div className="w-2.5 h-2.5 rounded-full" style={{ background: COLORS[i] }} />
                      <span className="text-[var(--text-secondary)]">{d.name}</span>
                    </div>
                    <span className="font-semibold" style={{ color: COLORS[i] }}>{d.value}</span>
                  </div>
                ))}
              </div>
            </>
          )}
        </motion.div>
      </div>

      {/* Bar chart */}
      <motion.div className="glass p-5"
        initial={{ opacity: 0, y: 16 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: 0.4 }}>
        <h3 className="font-semibold mb-4 text-sm">Daily Success vs Failure</h3>
        <ResponsiveContainer width="100%" height={180}>
          <BarChart data={chartData} barSize={10} barGap={4}>
            <CartesianGrid strokeDasharray="3 3" stroke="rgba(255,255,255,0.04)" />
            <XAxis dataKey="label" tick={{ fill: '#8b8a9e', fontSize: 11 }} axisLine={false} tickLine={false} />
            <YAxis tick={{ fill: '#8b8a9e', fontSize: 11 }} axisLine={false} tickLine={false} />
            <Tooltip content={<CustomTooltip />} />
            <Legend wrapperStyle={{ fontSize: 12, color: '#8b8a9e', paddingTop: 10 }} />
            <Bar dataKey="sent" name="Sent" fill="#8b5cf6" radius={[4, 4, 0, 0]} />
            <Bar dataKey="failed" name="Failed" fill="#ef4444" opacity={0.8} radius={[4, 4, 0, 0]} />
          </BarChart>
        </ResponsiveContainer>
      </motion.div>
    </div>
  );
}
