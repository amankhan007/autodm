'use client';
import { useEffect, useState } from 'react';
import { motion } from 'framer-motion';
import {
  MessageCircle, Send, TrendingUp, Zap, Activity,
  CheckCircle, XCircle, SkipForward, ArrowUpRight, RefreshCw
} from 'lucide-react';
import {
  AreaChart, Area, XAxis, YAxis, CartesianGrid,
  Tooltip, ResponsiveContainer, BarChart, Bar, Legend
} from 'recharts';
import api from '@/lib/api';
import { useAuthStore } from '@/store/authStore';

interface Stats {
  totalComments: number;
  totalDmsSent: number;
  totalDmsFailed: number;
  dmsToday: number;
  dmsThisWeek: number;
  conversionRate: number;
  activeCampaigns: number;
  totalCampaigns: number;
}

interface ChartPoint {
  label: string;
  sent: number;
  failed: number;
  comments: number;
}

const CustomTooltip = ({ active, payload, label }: any) => {
  if (!active || !payload?.length) return null;
  return (
    <div className="custom-tooltip">
      <p className="font-semibold text-white mb-2">{label}</p>
      {payload.map((p: any) => (
        <p key={p.name} style={{ color: p.color }} className="text-xs">
          {p.name}: {p.value}
        </p>
      ))}
    </div>
  );
};

export default function DashboardPage() {
  const { user } = useAuthStore();
  const [stats, setStats] = useState<Stats | null>(null);
  const [chartData, setChartData] = useState<ChartPoint[]>([]);
  const [activity, setActivity] = useState<any[]>([]);
  const [loading, setLoading] = useState(true);
  const [refreshing, setRefreshing] = useState(false);

  const fetchData = async (silent = false) => {
    if (!silent) setLoading(true);
    else setRefreshing(true);
    try {
      const [statsRes, activityRes] = await Promise.all([
        api.get('/api/dashboard/stats'),
        api.get('/api/dashboard/activity'),
      ]);
      setStats(statsRes.data.stats);
      setChartData(statsRes.data.chartData || []);
      setActivity(activityRes.data.logs || []);
    } catch {}
    finally { setLoading(false); setRefreshing(false); }
  };

  useEffect(() => { fetchData(); }, []);
  // Poll every 30 seconds
  useEffect(() => {
    const interval = setInterval(() => fetchData(true), 30000);
    return () => clearInterval(interval);
  }, []);

  const statCards = stats ? [
    { label: 'Total Comments', value: stats.totalComments.toLocaleString(), icon: MessageCircle, color: '#6366f1', change: `${stats.dmsToday} today` },
    { label: 'DMs Sent', value: stats.totalDmsSent.toLocaleString(), icon: Send, color: '#8b5cf6', change: `${stats.dmsThisWeek} this week` },
    { label: 'Conversion Rate', value: `${stats.conversionRate}%`, icon: TrendingUp, color: '#22c55e', change: 'comments → DMs' },
    { label: 'Active Campaigns', value: stats.activeCampaigns, icon: Zap, color: '#f59e0b', change: `of ${stats.totalCampaigns} total` },
  ] : [];

  const getStatusColor = (status: string) => ({
    success: '#22c55e',
    failed: '#ef4444',
    skipped: '#f59e0b',
    queued: '#6366f1',
    pending: '#8b8a9e',
  }[status] || '#8b8a9e');

  const getStatusIcon = (status: string) => ({
    success: <CheckCircle size={14} />,
    failed: <XCircle size={14} />,
    skipped: <SkipForward size={14} />,
    queued: <Activity size={14} />,
  }[status] || <Activity size={14} />);

  if (loading) {
    return (
      <div className="space-y-6">
        <div className="grid grid-cols-2 lg:grid-cols-4 gap-4">
          {[...Array(4)].map((_, i) => <div key={i} className="skeleton h-28 rounded-2xl" />)}
        </div>
        <div className="grid lg:grid-cols-3 gap-4">
          <div className="skeleton h-64 rounded-2xl lg:col-span-2" />
          <div className="skeleton h-64 rounded-2xl" />
        </div>
      </div>
    );
  }

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-2xl font-bold">Overview</h1>
          <p className="text-sm text-[var(--text-secondary)] mt-0.5">
            Welcome back, {user?.name?.split(' ')[0]}! Here's what's happening.
          </p>
        </div>
        <button onClick={() => fetchData(true)} disabled={refreshing}
          className="flex items-center gap-2 px-4 py-2 rounded-xl border border-white/8 bg-white/[0.03] hover:bg-white/[0.06] text-sm text-[var(--text-secondary)] hover:text-white transition-all">
          <RefreshCw size={14} className={refreshing ? 'animate-spin' : ''} />
          Refresh
        </button>
      </div>

      {/* Stat cards */}
      <div className="grid grid-cols-2 lg:grid-cols-4 gap-4">
        {statCards.map((s, i) => (
          <motion.div key={s.label} className="stat-card"
            initial={{ opacity: 0, y: 16 }} animate={{ opacity: 1, y: 0 }}
            transition={{ delay: i * 0.08 }}>
            <div className="flex items-start justify-between mb-4">
              <div className="w-9 h-9 rounded-xl flex items-center justify-center"
                style={{ background: s.color + '18', border: `1px solid ${s.color}30` }}>
                <s.icon size={17} style={{ color: s.color }} />
              </div>
              <ArrowUpRight size={14} className="text-[var(--text-muted)]" />
            </div>
            <div className="text-2xl font-extrabold mb-0.5" style={{ color: s.color }}>{s.value}</div>
            <div className="text-xs font-medium text-[var(--text-primary)] mb-1">{s.label}</div>
            <div className="text-xs text-[var(--text-muted)]">{s.change}</div>
          </motion.div>
        ))}
      </div>

      {/* Chart + Activity */}
      <div className="grid lg:grid-cols-3 gap-4">
        {/* Area chart */}
        <motion.div className="glass lg:col-span-2 p-5"
          initial={{ opacity: 0, y: 16 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: 0.3 }}>
          <h3 className="font-semibold mb-4 flex items-center gap-2">
            <Activity size={16} className="text-purple-400" /> 7-Day Activity
          </h3>
          <ResponsiveContainer width="100%" height={200}>
            <AreaChart data={chartData}>
              <defs>
                <linearGradient id="sentGrad" x1="0" y1="0" x2="0" y2="1">
                  <stop offset="5%" stopColor="#8b5cf6" stopOpacity={0.3} />
                  <stop offset="95%" stopColor="#8b5cf6" stopOpacity={0} />
                </linearGradient>
                <linearGradient id="commentGrad" x1="0" y1="0" x2="0" y2="1">
                  <stop offset="5%" stopColor="#6366f1" stopOpacity={0.2} />
                  <stop offset="95%" stopColor="#6366f1" stopOpacity={0} />
                </linearGradient>
              </defs>
              <CartesianGrid strokeDasharray="3 3" stroke="rgba(255,255,255,0.04)" />
              <XAxis dataKey="label" tick={{ fill: '#8b8a9e', fontSize: 11 }} axisLine={false} tickLine={false} />
              <YAxis tick={{ fill: '#8b8a9e', fontSize: 11 }} axisLine={false} tickLine={false} />
              <Tooltip content={<CustomTooltip />} />
              <Area type="monotone" dataKey="comments" name="Comments" stroke="#6366f1" fill="url(#commentGrad)" strokeWidth={2} />
              <Area type="monotone" dataKey="sent" name="DMs Sent" stroke="#8b5cf6" fill="url(#sentGrad)" strokeWidth={2} />
            </AreaChart>
          </ResponsiveContainer>
        </motion.div>

        {/* Live activity feed */}
        <motion.div className="glass p-5"
          initial={{ opacity: 0, y: 16 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: 0.4 }}>
          <div className="flex items-center justify-between mb-4">
            <h3 className="font-semibold flex items-center gap-2">
              <span className="w-2 h-2 rounded-full bg-green-400 animate-pulse" />
              Live Activity
            </h3>
            <a href="/dashboard/logs" className="text-xs text-purple-400 hover:text-purple-300">View all →</a>
          </div>
          <div className="space-y-0 overflow-y-auto max-h-48">
            {activity.length === 0 && (
              <div className="text-center py-8 text-[var(--text-muted)] text-sm">
                No activity yet.<br />Activate a campaign to start.
              </div>
            )}
            {activity.map((log: any) => (
              <div key={log._id} className="log-item">
                <div className="log-dot" style={{ background: getStatusColor(log.dmStatus) }} />
                <div className="flex-1 min-w-0">
                  <p className="text-xs font-medium truncate">
                    @{log.commenterUsername || 'Unknown'}
                  </p>
                  <p className="text-xs text-[var(--text-muted)] truncate">
                    {log.commentText?.substring(0, 40) || 'No comment text'}
                  </p>
                </div>
                <div style={{ color: getStatusColor(log.dmStatus) }}>
                  {getStatusIcon(log.dmStatus)}
                </div>
              </div>
            ))}
          </div>
        </motion.div>
      </div>

      {/* DM breakdown bar chart */}
      <motion.div className="glass p-5"
        initial={{ opacity: 0, y: 16 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: 0.5 }}>
        <h3 className="font-semibold mb-4">Daily DM Breakdown</h3>
        <ResponsiveContainer width="100%" height={160}>
          <BarChart data={chartData} barSize={12} barGap={3}>
            <CartesianGrid strokeDasharray="3 3" stroke="rgba(255,255,255,0.04)" />
            <XAxis dataKey="label" tick={{ fill: '#8b8a9e', fontSize: 11 }} axisLine={false} tickLine={false} />
            <YAxis tick={{ fill: '#8b8a9e', fontSize: 11 }} axisLine={false} tickLine={false} />
            <Tooltip content={<CustomTooltip />} />
            <Legend wrapperStyle={{ fontSize: 12, color: '#8b8a9e' }} />
            <Bar dataKey="sent" name="Sent" fill="#8b5cf6" radius={[4,4,0,0]} />
            <Bar dataKey="failed" name="Failed" fill="#ef4444" opacity={0.7} radius={[4,4,0,0]} />
          </BarChart>
        </ResponsiveContainer>
      </motion.div>
    </div>
  );
}
