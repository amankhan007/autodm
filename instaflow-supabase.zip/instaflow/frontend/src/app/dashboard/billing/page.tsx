'use client';
import { useEffect, useState } from 'react';
import { motion } from 'framer-motion';
import { CreditCard, CheckCircle, Zap, Calendar, RefreshCw, XCircle, Loader2, ExternalLink } from 'lucide-react';
import toast from 'react-hot-toast';
import api from '@/lib/api';
import { useAuthStore } from '@/store/authStore';

declare global { interface Window { Razorpay: any; } }

interface Payment { _id: string; amount: number; currency: string; status: string; createdAt: string; periodEnd: string; }

export default function BillingPage() {
  const { user, fetchMe } = useAuthStore();
  const [payments, setPayments] = useState<Payment[]>([]);
  const [loading, setLoading] = useState(true);
  const [subscribing, setSubscribing] = useState(false);
  const [cancelling, setCancelling] = useState(false);

  useEffect(() => {
    api.get('/api/payments/history')
      .then(r => setPayments(r.data.payments || []))
      .finally(() => setLoading(false));

    // Load Razorpay script
    if (!document.getElementById('razorpay-script')) {
      const script = document.createElement('script');
      script.id = 'razorpay-script';
      script.src = 'https://checkout.razorpay.com/v1/checkout.js';
      document.body.appendChild(script);
    }
  }, []);

  const handleSubscribe = async () => {
    setSubscribing(true);
    try {
      const { data } = await api.post('/api/payments/create-subscription');

      const options = {
        key: data.key,
        subscription_id: data.subscriptionId,
        name: 'InstaFlow',
        description: 'InstaFlow Pro — Monthly Subscription',
        image: '/logo.png',
        handler: async (response: any) => {
          try {
            await api.post('/api/payments/verify', {
              razorpay_payment_id: response.razorpay_payment_id,
              razorpay_subscription_id: response.razorpay_subscription_id,
              razorpay_signature: response.razorpay_signature,
            });
            toast.success('🎉 Subscription activated!');
            await fetchMe();
            const r = await api.get('/api/payments/history');
            setPayments(r.data.payments || []);
          } catch (err: any) {
            toast.error(err?.response?.data?.message || 'Payment verification failed');
          }
        },
        prefill: { email: user?.email, name: user?.name },
        theme: { color: '#8b5cf6' },
        modal: {
          ondismiss: () => setSubscribing(false),
        },
      };

      const rzp = new window.Razorpay(options);
      rzp.open();
      rzp.on('payment.failed', () => {
        toast.error('Payment failed. Please try again.');
        setSubscribing(false);
      });
    } catch (err: any) {
      toast.error(err?.response?.data?.message || 'Failed to initiate payment');
      setSubscribing(false);
    }
  };

  const handleCancel = async () => {
    if (!confirm('Cancel your subscription? You\'ll retain access until the end of the billing period.')) return;
    setCancelling(true);
    try {
      await api.post('/api/payments/cancel');
      toast.success('Subscription cancelled. You\'ll have access until your billing period ends.');
      await fetchMe();
    } catch (err: any) {
      toast.error(err?.response?.data?.message || 'Failed to cancel');
    } finally { setCancelling(false); }
  };

  const isActive = user?.subscriptionStatus === 'active';
  const features = ['Unlimited campaigns', 'All Instagram posts', 'Keyword triggers', 'Spam filter', 'Real-time analytics', 'CSV export', 'Email notifications', 'Priority support'];

  return (
    <div className="space-y-6 max-w-2xl">
      <div>
        <h1 className="text-2xl font-bold">Billing</h1>
        <p className="text-sm text-[var(--text-secondary)] mt-0.5">Manage your subscription and payment history</p>
      </div>

      {/* Current plan */}
      <motion.div className="glass p-6 rounded-2xl" initial={{ opacity: 0, y: 16 }} animate={{ opacity: 1, y: 0 }}>
        <div className="flex items-start justify-between mb-5">
          <div>
            <p className="text-xs font-semibold text-[var(--text-muted)] uppercase tracking-wider mb-1">Current Plan</p>
            <h2 className="text-xl font-bold">InstaFlow Pro</h2>
          </div>
          <span className={`badge ${isActive ? 'badge-success' : 'badge-neutral'}`}>
            {isActive ? '● Active' : user?.subscriptionStatus || 'Inactive'}
          </span>
        </div>

        <div className="flex items-end gap-1 mb-5">
          <span className="text-4xl font-extrabold text-gradient">₹199</span>
          <span className="text-[var(--text-secondary)] mb-1">/month</span>
        </div>

        {isActive && user?.subscriptionEnd && (
          <div className="flex items-center gap-2 text-sm text-[var(--text-secondary)] mb-5 p-3 rounded-xl bg-green-500/5 border border-green-500/10">
            <Calendar size={15} className="text-green-400" />
            <span>Next renewal: <strong className="text-white">{new Date(user.subscriptionEnd).toLocaleDateString('en-IN', { dateStyle: 'long' })}</strong></span>
          </div>
        )}

        <div className="grid grid-cols-2 gap-2 mb-6">
          {features.map(f => (
            <div key={f} className="flex items-center gap-2 text-sm">
              <CheckCircle size={14} className="text-green-400 flex-shrink-0" />
              <span className="text-[var(--text-secondary)]">{f}</span>
            </div>
          ))}
        </div>

        {!isActive ? (
          <button onClick={handleSubscribe} disabled={subscribing}
            className="btn-glow relative w-full flex items-center justify-center gap-2 text-white font-semibold py-3.5 rounded-xl disabled:opacity-60">
            <span className="relative z-10 flex items-center gap-2">
              {subscribing ? <Loader2 size={18} className="animate-spin" /> : <Zap size={18} />}
              {subscribing ? 'Opening payment…' : 'Subscribe Now — ₹199/month'}
            </span>
          </button>
        ) : (
          <button onClick={handleCancel} disabled={cancelling}
            className="w-full flex items-center justify-center gap-2 text-red-400 hover:text-red-300 border border-red-500/20 hover:border-red-500/40 py-2.5 rounded-xl text-sm font-medium transition-all disabled:opacity-60">
            {cancelling ? <Loader2 size={16} className="animate-spin" /> : <XCircle size={16} />}
            {cancelling ? 'Cancelling…' : 'Cancel Subscription'}
          </button>
        )}
      </motion.div>

      {/* Payment history */}
      <motion.div className="glass p-5 rounded-2xl" initial={{ opacity: 0, y: 16 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: 0.1 }}>
        <h3 className="font-semibold mb-4 flex items-center gap-2">
          <CreditCard size={16} className="text-purple-400" /> Payment History
        </h3>

        {loading ? (
          <div className="space-y-3">{[...Array(3)].map((_, i) => <div key={i} className="skeleton h-12 rounded-xl" />)}</div>
        ) : payments.length === 0 ? (
          <div className="text-center py-8 text-[var(--text-muted)] text-sm">
            <CreditCard size={28} className="mx-auto mb-2 opacity-20" />
            No payments yet
          </div>
        ) : (
          <div className="space-y-2">
            {payments.map(p => (
              <div key={p._id} className="flex items-center justify-between py-3 border-b border-white/5 last:border-0">
                <div>
                  <p className="text-sm font-medium">InstaFlow Pro — Monthly</p>
                  <p className="text-xs text-[var(--text-muted)]">
                    {new Date(p.createdAt).toLocaleDateString('en-IN', { dateStyle: 'medium' })}
                    {p.periodEnd && ` → ${new Date(p.periodEnd).toLocaleDateString('en-IN', { dateStyle: 'medium' })}`}
                  </p>
                </div>
                <div className="flex items-center gap-3">
                  <span className="font-semibold">₹{p.amount / 100}</span>
                  <span className={`badge ${p.status === 'captured' ? 'badge-success' : 'badge-danger'}`}>
                    {p.status === 'captured' ? 'Paid' : p.status}
                  </span>
                </div>
              </div>
            ))}
          </div>
        )}
      </motion.div>

      <p className="text-xs text-center text-[var(--text-muted)]">
        Payments processed securely by Razorpay. All amounts in INR.
      </p>
    </div>
  );
}
