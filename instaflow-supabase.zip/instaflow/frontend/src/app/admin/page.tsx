'use client';
import { useEffect, useState } from 'react';
import { motion } from 'framer-motion';
import { Shield, Users, TrendingUp, DollarSign, UserCheck, UserX, Loader2, Search, RefreshCw } from 'lucide-react';
import toast from 'react-hot-toast';
import api from '@/lib/api';
import { useAuthStore } from '@/store/authStore';
import { useRouter } from 'next/navigation';

interface AdminStats { totalUsers: number; activeSubscribers: number; totalDmsSent: number; totalRevenue: number; newUsersToday: number; }
interface UserRow { _id: string; name: string; email: string; subscriptionStatus: string; isActive: boolean; instagramUsername?: string; createdAt: string; dmsSentTotal: number; }

export default function AdminPage() {
  const { user } = useAuthStore();
  const router = useRouter();
  const [stats, setStats] = useState<AdminStats | null>(null);
  const [users, setUsers] = useState<UserRow[]>([]);
  const [loading, setLoading] = useState(true);
  const [search, setSearch] = useState('');
  const [statusFilter, setStatusFilter] = useState('all');
  const [toggling, setToggling] = useState<string | null>(null);

  useEffect(() => {
    if (user && user.role !== 'admin') { router.push('/dashboard'); return; }
    fetchData();
  }, [user]);

  const fetchData = async () => {
    setLoading(true);
    try {
      const [statsRes, usersRes] = await Promise.all([
        api.get('/api/admin/stats'),
        api.get('/api/admin/users?limit=50'),
      ]);
      setStats(statsRes.data.stats);
      setUsers(usersRes.data.users);
    } catch { toast.error('Failed to load admin data'); }
    finally { setLoading(false); }
  };

  const fetchUsers = async () => {
    const params = new URLSearchParams({ limit: '50' });
    if (search) params.set('search', search);
    if (statusFilter !== 'all') params.set('status', statusFilter);
    const { data } = await api.get(`/api/admin/users?${params}`);
    setUsers(data.users);
  };

  useEffect(() => { if (!loading) fetchUsers(); }, [search, statusFilter]);

  const toggleUser = async (id: string, current: boolean) => {
    setToggling(id);
    try {
      await api.patch(`/api/admin/users/${id}/toggle`);
      setUsers(prev => prev.map(u => u._id === id ? { ...u, isActive: !current } : u));
      toast.success(current ? 'User suspended' : 'User activated');
    } catch { toast.error('Failed to update user'); }
    finally { setToggling(null); }
  };

  const grantDays = async (id: string, days: number) => {
    try {
      await api.patch(`/api/admin/users/${id}/subscription`, { status: 'active', daysToAdd: days });
      toast.success(`${days} days added`);
      fetchData();
    } catch { toast.error('Failed to update subscription'); }
  };

  const statCards = stats ? [
    { label: 'Total Users', value: stats.totalUsers.toLocaleString(), icon: Users, color: '#6366f1' },
    { label: 'Active Subscribers', value: stats.activeSubscribers.toLocaleString(), icon: UserCheck, color: '#22c55e' },
    { label: 'Total DMs Sent', value: stats.totalDmsSent.toLocaleString(), icon: TrendingUp, color: '#8b5cf6' },
    { label: 'Total Revenue', value: `₹${stats.totalRevenue?.toLocaleString('en-IN')}`, icon: DollarSign, color: '#f59e0b' },
  ] : [];

  return (
    <div className="space-y-6">
      <div className="flex items-center gap-3">
        <div className="w-10 h-10 rounded-xl bg-purple-500/20 flex items-center justify-center">
          <Shield size={20} className="text-purple-400" />
        </div>
        <div>
          <h1 className="text-2xl font-bold">Admin Panel</h1>
          <p className="text-sm text-[var(--text-secondary)]">Platform management & oversight</p>
        </div>
        <button onClick={fetchData} className="ml-auto p-2 rounded-xl border border-white/10 text-[var(--text-secondary)] hover:text-white hover:bg-white/5">
          <RefreshCw size={16} className={loading ? 'animate-spin' : ''} />
        </button>
      </div>

      {/* Stats */}
      <div className="grid grid-cols-2 lg:grid-cols-4 gap-4">
        {statCards.map((s, i) => (
          <motion.div key={s.label} className="stat-card"
            initial={{ opacity: 0, y: 16 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: i * 0.08 }}>
            <div className="w-9 h-9 rounded-xl flex items-center justify-center mb-3"
              style={{ background: s.color + '18', border: `1px solid ${s.color}30` }}>
              <s.icon size={17} style={{ color: s.color }} />
            </div>
            <div className="text-2xl font-extrabold mb-0.5" style={{ color: s.color }}>{s.value}</div>
            <div className="text-xs text-[var(--text-muted)]">{s.label}</div>
          </motion.div>
        ))}
      </div>

      {/* Users table */}
      <div className="glass rounded-2xl overflow-hidden">
        <div className="p-4 border-b border-white/5 flex items-center gap-3 flex-wrap">
          <div className="relative flex-1 min-w-48">
            <Search size={14} className="absolute left-3 top-1/2 -translate-y-1/2 text-[var(--text-muted)]" />
            <input value={search} onChange={e => setSearch(e.target.value)}
              placeholder="Search users…" className="input-dark pl-9 text-sm py-2" />
          </div>
          <div className="flex gap-1">
            {['all','active','inactive','expired'].map(s => (
              <button key={s} onClick={() => setStatusFilter(s)}
                className={`px-3 py-1.5 rounded-lg text-xs capitalize transition-all ${statusFilter === s ? 'bg-purple-500/20 text-purple-300 border border-purple-500/30' : 'text-[var(--text-muted)] hover:text-white hover:bg-white/5'}`}>
                {s}
              </button>
            ))}
          </div>
        </div>

        {loading ? (
          <div className="p-6 space-y-3">{[...Array(5)].map((_, i) => <div key={i} className="skeleton h-12 rounded-xl" />)}</div>
        ) : (
          <div className="divide-y divide-white/[0.04]">
            <div className="grid grid-cols-12 gap-2 px-5 py-3 text-xs font-semibold text-[var(--text-muted)] uppercase tracking-wider">
              <div className="col-span-3">User</div>
              <div className="col-span-2">Instagram</div>
              <div className="col-span-2">Subscription</div>
              <div className="col-span-1 text-center">DMs</div>
              <div className="col-span-2">Joined</div>
              <div className="col-span-2 text-right">Actions</div>
            </div>

            {users.map(u => (
              <div key={u._id} className="grid grid-cols-12 gap-2 px-5 py-3.5 hover:bg-white/[0.02] transition-colors text-sm items-center">
                <div className="col-span-3 min-w-0">
                  <p className="font-medium truncate">{u.name}</p>
                  <p className="text-xs text-[var(--text-muted)] truncate">{u.email}</p>
                </div>
                <div className="col-span-2 text-xs text-[var(--text-secondary)] truncate">
                  {u.instagramUsername ? `@${u.instagramUsername}` : '—'}
                </div>
                <div className="col-span-2">
                  <span className={`badge text-[10px] ${
                    u.subscriptionStatus === 'active' ? 'badge-success' :
                    u.subscriptionStatus === 'expired' ? 'badge-danger' : 'badge-neutral'
                  }`}>{u.subscriptionStatus}</span>
                </div>
                <div className="col-span-1 text-center text-xs text-[var(--text-secondary)]">{u.dmsSentTotal || 0}</div>
                <div className="col-span-2 text-xs text-[var(--text-muted)]">
                  {new Date(u.createdAt).toLocaleDateString('en-IN', { dateStyle: 'short' })}
                </div>
                <div className="col-span-2 flex items-center justify-end gap-1">
                  <button onClick={() => grantDays(u._id, 30)}
                    className="px-2 py-1 text-[10px] rounded-lg bg-purple-500/10 text-purple-300 hover:bg-purple-500/20 border border-purple-500/20">
                    +30d
                  </button>
                  <button onClick={() => toggleUser(u._id, u.isActive)} disabled={toggling === u._id}
                    className={`p-1.5 rounded-lg transition-all ${u.isActive ? 'text-red-400 hover:bg-red-500/10' : 'text-green-400 hover:bg-green-500/10'}`}>
                    {toggling === u._id ? <Loader2 size={13} className="animate-spin" /> : u.isActive ? <UserX size={13} /> : <UserCheck size={13} />}
                  </button>
                </div>
              </div>
            ))}
          </div>
        )}
      </div>
    </div>
  );
}
